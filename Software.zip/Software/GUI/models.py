from dataclasses import dataclass, field
import uuid
from typing import Dict, Any
from PyQt6.QtGui import QColor

APP_NAME = "Smart Breadboard Studio"
BREADBOARD_COLS = 30
BREADBOARD_ROWS = 14

@dataclass(frozen=True)
class NodeRef:
    row: int
    col: int

@dataclass
class Wire:
    a: NodeRef
    b: NodeRef
    color: QColor
    route_offset: float = 0.0

@dataclass
class VirtualComponent:
    id: str
    type: str  # 'signal', 'power', 'probe', 'cap_meter'
    node: NodeRef
    channel: int # 0-3 hardware bounds
    properties: Dict[str, Any] = field(default_factory=dict)