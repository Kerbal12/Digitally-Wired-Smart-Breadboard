import math
import numpy as np
from PyQt6.QtCore import Qt, QTimer, QPointF
from PyQt6.QtGui import QFont, QColor, QPainter, QPainterPath, QPen, QBrush
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, 
    QPushButton, QLineEdit, QComboBox, QGridLayout, 
    QDialog, QSizePolicy, QCheckBox, QSlider
)
import pyqtgraph as pg

# Configure pyqtgraph for maximum performance
pg.setConfigOptions(useOpenGL=True, antialias=True, background="#0d1117", foreground="#c9d1d9")

from instrument_backend import InstrumentBackend, PROTOCOL, FS, BUFFER, INPUT_V_MIN, INPUT_V_MAX, DAC_VREF
from models import VirtualComponent

COLOR_GRID = "#30363d"
COLOR_SPINE = "#21262d"
COLOR_TEXT = "#c9d1d9"
COLOR_ACTIVE = "#238636"
BG_PANEL = "#161b22"
CH_COLORS = ["#ffd166", "#06d6a0"]

class DsoCanvas(pg.GraphicsLayoutWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        
        self.ax1 = self.addPlot(title="WAVEFORM")
        self.nextRow()
        self.ax2 = self.addPlot(title="SPECTRUM")
        
        self.scene().sigMouseClicked.connect(self.on_mouse_click)
        
        for ax in (self.ax1, self.ax2):
            ax.setMouseEnabled(x=True, y=False)
            ax.showGrid(x=True, y=True, alpha=0.5)
            # Custom spine colors to match theme
            ax.getAxis('bottom').setPen(pg.mkPen(COLOR_SPINE, width=1.2))
            ax.getAxis('bottom').setTextPen(COLOR_TEXT)
            ax.getAxis('left').setPen(pg.mkPen(COLOR_SPINE, width=1.2))
            ax.getAxis('left').setTextPen(COLOR_TEXT)
            
        self.ax1.setLimits(xMin=0, xMax=(BUFFER-1)/FS)
        self.ax2.setLimits(xMin=-50, xMax=FS/2 + 50, yMin=-0.1, yMax=10.0)
        
        self.ax1.setLabel('left', 'Voltage', units='V')
        self.ax1.getAxis('left').enableAutoSIPrefix(True)
        self.ax1.setLabel('bottom', 'Time', units='s')
        self.ax1.setYRange(INPUT_V_MIN, INPUT_V_MAX)
        self.ax1.setXRange(0, (BUFFER - 1) / FS)
        
        self.ax2.setLabel('left', 'Amplitude', units='V')
        self.ax2.getAxis('left').enableAutoSIPrefix(True)
        self.ax2.setLabel('bottom', 'Frequency', units='Hz')
        self.ax2.setLimits(xMin=-50, xMax=FS/2 + 50, yMin=-0.1, yMax=10000.0)
        self.ax2.setXRange(0, FS / 2)
        self.ax2.setYRange(0, 0.1)
        
        self.lines1 = []
        self.lines2 = []
        self.ref_lines1 = []
        
        for i in range(2):
            c = CH_COLORS[i]
            pen = pg.mkPen(color=c, width=1.2)
            l1 = self.ax1.plot(pen=pen)
            l2 = self.ax2.plot(pen=pen)
            l1.setDownsampling(auto=True, method='subsample')
            l2.setDownsampling(auto=True, method='subsample')
            ref = pg.InfiniteLine(pos=0, angle=0, pen=pg.mkPen(color=c, width=1, style=Qt.PenStyle.DotLine))
            self.ax1.addItem(ref)
            
            l1.setVisible(False)
            l2.setVisible(False)
            ref.setVisible(False)
            
            self.lines1.append(l1)
            self.lines2.append(l2)
            self.ref_lines1.append(ref)
            
        # Initial visible state
        self.lines1[0].setVisible(True)
        self.lines2[0].setVisible(True)
        self.ref_lines1[0].setVisible(True)

    def on_mouse_click(self, ev):
        if ev.double() and getattr(self.parent(), 'maximize_view', None):
            self.parent().maximize_view()

class DetachedChannelWindow(QDialog):
    def __init__(self, backend, ch, parent=None):
        super().__init__(parent)
        self.backend = backend
        self.ch = ch
        self.setWindowTitle(f"Detached Analysis - Channel D{ch+1}")
        self.resize(700, 500)
        self.setWindowFlag(Qt.WindowType.Window)
        
        self.window_fn = np.hanning(BUFFER)
        self.window_gain = np.sum(self.window_fn) / BUFFER
        layout = QVBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)
        
        header = QHBoxLayout()
        self.btn_fit = QPushButton("⛶ Fit Timebase")
        self.btn_fit.clicked.connect(self.fit_timebase)
        self.btn_fit.setStyleSheet("padding: 6px 12px; background-color: #21262d; border-radius: 4px;")
        header.addWidget(self.btn_fit)
        
        self.btn_pause = QPushButton(f"⏸ Freeze D{self.ch+1}")
        self.btn_pause.setCheckable(True)
        self.btn_pause.setStyleSheet("""
            QPushButton { padding: 6px 12px; border-radius: 4px; font-weight: bold; background-color: #161b22; color: #8E8E93; border: 1px solid #30363d; }
            QPushButton:checked { background-color: #d73a49; color: #fff; border: 1px solid #d73a49; }
        """)
        header.addWidget(self.btn_pause)
        
        header.addStretch(1)
        layout.addLayout(header)
        
        self.canvas = pg.GraphicsLayoutWidget()
        layout.addWidget(self.canvas)
        
        self.ax_t = self.canvas.addPlot(title=f"D{ch+1} Time Domain")
        self.canvas.nextRow()
        self.ax_f = self.canvas.addPlot(title=f"D{ch+1} Frequency Spectrum")
        
        for ax in (self.ax_t, self.ax_f):
            ax.setMouseEnabled(x=True, y=False)
            ax.showGrid(x=True, y=True, alpha=0.5)
            ax.getAxis('bottom').setPen(pg.mkPen(COLOR_SPINE, width=1.2))
            ax.getAxis('bottom').setTextPen(COLOR_TEXT)
            ax.getAxis('left').setPen(pg.mkPen(COLOR_SPINE, width=1.2))
            ax.getAxis('left').setTextPen(COLOR_TEXT)
            
        self.ax_t.setLimits(xMin=0, xMax=(BUFFER-1)/FS)
        self.ax_f.setLimits(xMin=-50, xMax=FS/2 + 50, yMin=-0.1, yMax=10.0)
            
        self.ax_t.setLabel('left', 'Voltage', units='V')
        self.ax_f.setLabel('left', 'Amplitude', units='V')
        
        self.ax_t.getAxis('left').enableAutoSIPrefix(True)
        self.ax_f.getAxis('left').enableAutoSIPrefix(True)
        
        c = CH_COLORS[ch]
        self.line_t = self.ax_t.plot(pen=pg.mkPen(color=c, width=1.2))
        self.line_f = self.ax_f.plot(pen=pg.mkPen(color=c, width=1.2))
        
        ref = pg.InfiniteLine(pos=0, angle=0, pen=pg.mkPen(color=c, width=1, style=Qt.PenStyle.DotLine))
        self.ax_t.addItem(ref)
        
        self.v_min_ema = -1.0
        self.v_max_ema = 1.0
        
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_plot)
        self.timer.start(50)
        
    def fit_timebase(self):
        fs = self.backend.estimated_fs if PROTOCOL == "csv" else FS
        if self.backend.is_connected() and fs > 0:
            self.ax_t.setXRange(0, (BUFFER - 1) / fs)

    def update_plot(self):
        if not self.backend.is_connected() or len(self.backend.data_buffer) < BUFFER: return
        if self.btn_pause.isChecked(): return
        fs = self.backend.estimated_fs if PROTOCOL == "csv" else FS
        y = np.array(self.backend.data_buffer, dtype=np.float32)
        
        try:
            from instrument_backend import CALIB_MAP_CH1_XP, CALIB_MAP_CH1_YP, CALIB_MAP_CH2_XP, CALIB_MAP_CH2_YP
            if self.ch == 0:
                volts = np.interp(y[:, self.ch], CALIB_MAP_CH1_XP, CALIB_MAP_CH1_YP)
            else:
                volts = np.interp(y[:, self.ch], CALIB_MAP_CH2_XP, CALIB_MAP_CH2_YP)
        except ImportError:
            volts = INPUT_V_MIN + y[:, self.ch] * ((INPUT_V_MAX - INPUT_V_MIN) / 4095.0)
        
        x_time = np.arange(BUFFER) / fs
        self.line_t.setData(x_time, volts)
        
        try:
            signal = volts - np.mean(volts)
            windowed = signal * self.window_fn
            yf = np.abs(np.fft.rfft(windowed)) / (BUFFER * self.window_gain) * 2
            freqs = np.fft.rfftfreq(BUFFER, 1/max(fs, 1.0))
            self.line_f.setData(freqs, yf)
        except Exception:
            yf = np.array([0.0])
        
        vmin, vmax = float(np.min(volts)), float(np.max(volts))
        span = vmax - vmin
        m = max(span * 0.15, 0.1)
        
        if self.v_min_ema == -1.0:
            self.v_min_ema = vmin - m
            self.v_max_ema = vmax + m
            
        self.v_min_ema = self.v_min_ema * 0.85 + (vmin - m) * 0.15
        self.v_max_ema = self.v_max_ema * 0.85 + (vmax + m) * 0.15
        
        self.ax_t.setYRange(self.v_min_ema, self.v_max_ema)
        self.ax_f.setYRange(0, max(0.01, np.max(yf[1:])*1.2) if len(yf)>1 else 0.1)


class MaximizedDsoDialog(QDialog):
    def __init__(self, backend, parent=None):
        super().__init__(parent)
        self.backend = backend
        self.setWindowTitle("Oscilloscope - Multi-Channel Workspace")
        self.resize(1200, 800)
        self.setWindowFlag(Qt.WindowType.Window)
        
        self.channel_order = [0, 1]
        self.window_fn = np.hanning(BUFFER)
        self.window_gain = np.sum(self.window_fn) / BUFFER
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)
        
        tools = QHBoxLayout()
        self.btn_fit = QPushButton("⛶ Fit Timebase")
        self.btn_fit.clicked.connect(self.fit_timebase)
        self.btn_fit.setStyleSheet("padding: 6px 12px; background-color: #21262d; border-radius: 4px;")
        tools.addWidget(self.btn_fit)
        
        tools.addSpacing(20)
        self.btn_pauses = []
        for i in range(2):
            btn_freeze = QPushButton(f"⏸ Freeze D{i+1}")
            btn_freeze.setCheckable(True)
            btn_freeze.setStyleSheet("""
                QPushButton { padding: 4px 8px; border-radius: 4px; font-weight: bold; background-color: #161b22; color: #8E8E93; border: 1px solid #30363d; }
                QPushButton:checked { background-color: #d73a49; color: #fff; border: 1px solid #d73a49; }
            """)
            btn_freeze.clicked.connect(lambda checked, ch=i: self.toggle_pause(ch))
            self.btn_pauses.append(btn_freeze)
            tools.addWidget(btn_freeze)
            
        tools.addSpacing(20)
        tools.addWidget(QLabel("Reorder:"))
        self.cb_order = QComboBox()
        self.cb_order.addItems(["D1", "D2"])
        tools.addWidget(self.cb_order)
        
        self.btn_up = QPushButton("▲ Up")
        self.btn_up.clicked.connect(self.move_up)
        self.btn_down = QPushButton("▼ Down")
        self.btn_down.clicked.connect(self.move_down)
        tools.addWidget(self.btn_up)
        tools.addWidget(self.btn_down)
        
        tools.addStretch(1)
        layout.addLayout(tools)
        
        self.canvas = pg.GraphicsLayoutWidget()
        self.canvas.scene().sigMouseClicked.connect(self.on_mouse_click)
        layout.addWidget(self.canvas)
        
        self._updating_range = False
        
        self.ax_t_list = []
        self.ax_f_list = []
        self.lines_t = []
        self.lines_f = []
        self.ref_lines_t = []
        
        for i in range(2):
            ax_t = self.canvas.addPlot()
            ax_f = self.canvas.addPlot()
            self.canvas.nextRow()
            
            for ax in (ax_t, ax_f):
                ax.setMouseEnabled(x=True, y=False)
                ax.showGrid(x=True, y=True, alpha=0.5)
                ax.getAxis('bottom').setPen(pg.mkPen(COLOR_SPINE, width=1.2))
                ax.getAxis('bottom').setTextPen(COLOR_TEXT)
                ax.getAxis('left').setPen(pg.mkPen(COLOR_SPINE, width=1.2))
                ax.getAxis('left').setTextPen(COLOR_TEXT)
                
            ax_t.setLimits(xMin=0, xMax=(BUFFER-1)/FS)
            ax_f.setLimits(xMin=-50, xMax=FS/2 + 50, yMin=-100.0, yMax=10000.0)
            
            self.ax_t_list.append(ax_t)
            self.ax_f_list.append(ax_f)
            
            if i > 0:
                ax_t.setXLink(self.ax_t_list[0])
                ax_f.setXLink(self.ax_f_list[0])
            
            l_t = ax_t.plot(pen=pg.mkPen(color=CH_COLORS[i], width=1.2))
            l_f = ax_f.plot(pen=pg.mkPen(color=CH_COLORS[i], width=1.2))
            l_t.setDownsampling(auto=True, method='subsample')
            l_f.setDownsampling(auto=True, method='subsample')
            
            ref_t = pg.InfiniteLine(pos=0, angle=0, pen=pg.mkPen(color=CH_COLORS[i], width=1, style=Qt.PenStyle.DotLine))
            ax_t.addItem(ref_t)
            
            self.lines_t.append(l_t)
            self.lines_f.append(l_f)
            self.ref_lines_t.append(ref_t)
            
        self.ax_t_list[-1].setLabel('bottom', 'Time', units='s')
        self.ax_f_list[-1].setLabel('bottom', 'Frequency', units='Hz')
        
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_plot)
        self.timer.start(50)
        
        self.detached_windows = {}
        self.paused_ch = [False, False]
        self.v_min_ema = [-1.0, -1.0]
        self.v_max_ema = [1.0, 1.0]
        self.refresh_titles()

    def on_mouse_click(self, ev):
        if ev.double():
            pos = ev.scenePos()
            for i, ax_t in enumerate(self.ax_t_list):
                if ax_t.sceneBoundingRect().contains(pos) or self.ax_f_list[i].sceneBoundingRect().contains(pos):
                    ch = self.channel_order[i]
                    if ch not in self.detached_windows or not self.detached_windows[ch].isVisible():
                        self.detached_windows[ch] = DetachedChannelWindow(self.backend, ch, self.window())
                        self.detached_windows[ch].show()
                    else:
                        self.detached_windows[ch].raise_()
                    break

    def toggle_pause(self, ch):
        self.paused_ch[ch] = self.btn_pauses[ch].isChecked()

    def fit_timebase(self):
        fs = self.backend.estimated_fs if PROTOCOL == "csv" else FS
        if self.backend.is_connected() and fs > 0:
            self.ax_t_list[0].setXRange(0, (BUFFER - 1) / fs)

    def refresh_titles(self):
        for i in range(2):
            ch = self.channel_order[i]
            c = CH_COLORS[ch]
            
            self.ax_t_list[i].setTitle(f"Channel D{ch+1} - Time Domain", color=c)
            self.ax_t_list[i].setLabel('left', 'Voltage', units='V')
            self.ax_t_list[i].getAxis('left').enableAutoSIPrefix(True)
            
            self.ax_f_list[i].setTitle(f"Channel D{ch+1} - Frequency Spectrum", color=c)
            self.ax_f_list[i].setLabel('left', 'Amplitude', units='V')
            self.ax_f_list[i].getAxis('left').enableAutoSIPrefix(True)
            
            self.lines_t[i].setPen(pg.mkPen(color=c, width=1.2))
            self.lines_f[i].setPen(pg.mkPen(color=c, width=1.2))
            self.ref_lines_t[i].setPen(pg.mkPen(color=c, width=1, style=Qt.PenStyle.DotLine))

    def move_up(self):
        ch_str = self.cb_order.currentText()
        ch = int(ch_str[1]) - 1
        idx = self.channel_order.index(ch)
        if idx > 0:
            self.channel_order[idx], self.channel_order[idx-1] = self.channel_order[idx-1], self.channel_order[idx]
        self.refresh_titles()

    def move_down(self):
        ch_str = self.cb_order.currentText()
        ch = int(ch_str[1]) - 1
        idx = self.channel_order.index(ch)
        if idx < 1:
            self.channel_order[idx], self.channel_order[idx+1] = self.channel_order[idx+1], self.channel_order[idx]
        self.refresh_titles()

    def update_plot(self):
        if not self.backend.is_connected() or len(self.backend.data_buffer) < BUFFER: return
        fs = self.backend.estimated_fs if PROTOCOL == "csv" else FS
        y = np.array(self.backend.data_buffer, dtype=np.float32)
        volts_arr = np.zeros_like(y)
        try:
            from instrument_backend import CALIB_MAP_CH1_XP, CALIB_MAP_CH1_YP, CALIB_MAP_CH2_XP, CALIB_MAP_CH2_YP
            volts_arr[:, 0] = np.interp(y[:, 0], CALIB_MAP_CH1_XP, CALIB_MAP_CH1_YP)
            volts_arr[:, 1] = np.interp(y[:, 1], CALIB_MAP_CH2_XP, CALIB_MAP_CH2_YP)
        except ImportError:
            volts_arr = INPUT_V_MIN + y * ((INPUT_V_MAX - INPUT_V_MIN) / 4095.0)
        x_time = np.arange(BUFFER) / fs
        freqs = np.fft.rfftfreq(BUFFER, 1/fs)
        
        for i in range(2):
            ch = self.channel_order[i]
            if self.paused_ch[ch]:
                continue
            
            volts = volts_arr[:, ch]
            ax_t = self.ax_t_list[i]
            ax_f = self.ax_f_list[i]
            
            self.lines_t[i].setData(x_time, volts)
            
            try:
                signal = volts - np.mean(volts)
                windowed = signal * self.window_fn
                yf = np.abs(np.fft.rfft(windowed)) / (BUFFER * self.window_gain) * 2
                self.lines_f[i].setData(freqs, yf)
            except Exception:
                yf = np.array([0.0])
            
            vmin, vmax = float(np.min(volts)), float(np.max(volts))
            span = vmax - vmin
            m = max(span * 0.15, 0.1)
            
            if self.v_min_ema[i] == -1.0:
                self.v_min_ema[i] = vmin - m
                self.v_max_ema[i] = vmax + m
                
            self.v_min_ema[i] = self.v_min_ema[i] * 0.85 + (vmin - m) * 0.15
            self.v_max_ema[i] = self.v_max_ema[i] * 0.85 + (vmax + m) * 0.15
            
            ax_t.setYRange(self.v_min_ema[i], self.v_max_ema[i])
            ax_f.setYRange(0, max(0.01, np.max(yf[1:])*1.2) if len(yf)>1 else 0.1)


class DsoWidget(QFrame):
    def __init__(self):
        super().__init__()
        self.setObjectName("InstrumentContainer")
        self.backend = InstrumentBackend()
        
        self.paused_ch = [False, False]
        self.cached_ch_volts = {0: None, 1: None}
        self.v_min_ema = [-1.0, -1.0]
        self.v_max_ema = [1.0, 1.0]

        self.window_fn = np.hanning(BUFFER)
        self.window_gain = np.sum(self.window_fn) / BUFFER

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(6)
        
        # TOP HEADER STRIP
        top_bar = QHBoxLayout()
        title = QLabel("DSO")
        title.setObjectName("PanelTitle")
        title.setStyleSheet("font-size: 16px; min-width: 40px;")
        top_bar.addWidget(title)
        top_bar.addSpacing(10)
        
        self.btn_channels = []
        for i in range(2):
            c = CH_COLORS[i]
            btn = QPushButton(f"D{i+1}")
            btn.setCheckable(True)
            btn.setStyleSheet(f"""
                QPushButton {{ padding: 6px 12px; border-radius: 4px; background-color: #161b22; color: {c}; border: 1px solid {c}; }}
                QPushButton:checked {{ background-color: {c}; color: {"#000" if i == 0 else "#fff"}; font-weight: bold; border: 1px solid {c}; }}
            """)
            btn.clicked.connect(self.update_channel_visibility)
            self.btn_channels.append(btn)
            top_bar.addWidget(btn)
            
        self.btn_channels[0].setChecked(True)
        self.btn_channels[1].setChecked(True)
        
        top_bar.addStretch()
        
        self.btn_fit = QPushButton("⛶ Fit Timebase")
        self.btn_fit.clicked.connect(self.fit_timebase)
        self.btn_fit.setStyleSheet("padding: 6px 12px; background-color: #21262d; border-radius: 4px;")
        top_bar.addWidget(self.btn_fit)
        
        self.btn_max = QPushButton("◱ Expand Workspace")
        self.btn_max.clicked.connect(self.maximize_view)
        self.btn_max.setStyleSheet("padding: 6px 12px; background-color: #21262d; border-radius: 4px;")
        top_bar.addWidget(self.btn_max)
        
        layout.addLayout(top_bar)

        self.status_lbl = QLabel("Acquiring...")
        self.status_lbl.setStyleSheet("font-family: monospace; font-size: 11px; color: #8E8E93;")
        self.status_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.status_lbl)

        # FREEZE TRACE STRIP (Directly above canvas)
        freeze_bar = QHBoxLayout()
        self.btn_pause_all = QPushButton("⏸ Freeze All (Phase Lock)")
        self.btn_pause_all.setCheckable(True)
        self.btn_pause_all.setStyleSheet("""
            QPushButton { padding: 4px 8px; border-radius: 4px; font-weight: bold; font-size:11px; background-color: #161b22; color: #8E8E93; border: 1px solid #30363d; }
            QPushButton:checked { background-color: #d73a49; color: #fff; border: 1px solid #d73a49; }
        """)
        self.btn_pause_all.clicked.connect(self.toggle_pause_all)
        freeze_bar.addWidget(self.btn_pause_all)
        freeze_bar.addStretch()
        layout.addLayout(freeze_bar)

        self.canvas = DsoCanvas(self)
        layout.addWidget(self.canvas, 1)

        self.update_channel_visibility()

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_plot)
        self.timer.start(30) # run faster with pyqtgraph!
        self.detached_dialog = None

    def update_channel_visibility(self):
        for i in range(2):
            visible = self.btn_channels[i].isChecked()
            self.canvas.lines1[i].setVisible(visible)
            self.canvas.lines2[i].setVisible(visible)
            self.canvas.ref_lines1[i].setVisible(visible)

    def toggle_pause_all(self, checked):
        self.paused_ch[0] = self.btn_pause_all.isChecked()
        self.paused_ch[1] = self.btn_pause_all.isChecked()

    def fit_timebase(self):
        fs = self.backend.estimated_fs if PROTOCOL == "csv" else FS
        if self.backend.is_connected() and fs > 0:
            self.canvas.ax1.setXRange(0, (BUFFER - 1) / fs)

    def maximize_view(self):
        if self.detached_dialog is None or not self.detached_dialog.isVisible():
            self.detached_dialog = MaximizedDsoDialog(self.backend, self.window())
            self.detached_dialog.show()
        else:
            self.detached_dialog.raise_()
            self.detached_dialog.activateWindow()

    def update_plot(self):
        backend = self.backend
        if not backend.is_connected():
            self.status_lbl.setText("⚠ DISCONNECTED │ No COM port found")
            return
            
        fs_use = backend.estimated_fs if PROTOCOL == "csv" else FS
        x_time_use = np.arange(BUFFER) / max(fs_use, 1.0)
        freqs = np.fft.rfftfreq(BUFFER, 1 / max(fs_use, 1.0))
        
        if len(backend.data_buffer) < BUFFER:
            # We don't return entirely if paused cache exists
            y = np.zeros((BUFFER, 2), dtype=np.float32)
        else:
            y = np.array(backend.data_buffer, dtype=np.float32)
            
        volts_arr = np.zeros_like(y)
        try:
            from instrument_backend import CALIB_MAP_CH1_XP, CALIB_MAP_CH1_YP, CALIB_MAP_CH2_XP, CALIB_MAP_CH2_YP
            if y.shape[1] >= 1: volts_arr[:, 0] = np.interp(y[:, 0], CALIB_MAP_CH1_XP, CALIB_MAP_CH1_YP)
            if y.shape[1] >= 2: volts_arr[:, 1] = np.interp(y[:, 1], CALIB_MAP_CH2_XP, CALIB_MAP_CH2_YP)
        except ImportError:
            volts_arr = INPUT_V_MIN + y * ((INPUT_V_MAX - INPUT_V_MIN) / 4095.0)
        
        v_min_global = float('inf')
        v_max_global = float('-inf')
        yf_max_global = 0.01

        active_channels = []
        is_fully_paused = True

        for ch in range(2):
            if not self.btn_channels[ch].isChecked():
                continue
                
            active_channels.append(str(ch+1))
            
            if self.paused_ch[ch]:
                if self.cached_ch_volts[ch] is not None:
                    # Maintain global view bounds but skip plotting entirely (stops the jitter!)
                    v_min, v_max = float(np.min(self.cached_ch_volts[ch])), float(np.max(self.cached_ch_volts[ch]))
                    if v_min < v_min_global: v_min_global = v_min
                    if v_max > v_max_global: v_max_global = v_max
                    
                    if hasattr(self, 'cached_yf_max') and ch in self.cached_yf_max:
                        if self.cached_yf_max[ch] > yf_max_global: yf_max_global = self.cached_yf_max[ch]
                continue
                
            is_fully_paused = False
            volts = volts_arr[:, ch]
            self.cached_ch_volts[ch] = volts.copy()
            self.canvas.lines1[ch].setData(x_time_use, volts)
            
            v_min, v_max = float(np.min(volts)), float(np.max(volts))
            if v_min < v_min_global: v_min_global = v_min
            if v_max > v_max_global: v_max_global = v_max

            try:
                signal = volts - np.mean(volts)
                windowed = signal * self.window_fn
                yf = np.abs(np.fft.rfft(windowed)) / (BUFFER * self.window_gain) * 2
                self.canvas.lines2[ch].setData(freqs, yf)
                
                max_yf = np.max(yf[1:]) if len(yf) > 1 else 0.01
                if max_yf > yf_max_global: yf_max_global = max_yf
                
                if not hasattr(self, 'cached_yf_max'): self.cached_yf_max = {}
                self.cached_yf_max[ch] = max_yf
            except Exception:
                pass

        if active_channels and not is_fully_paused:
            if v_min_global != float('inf'):
                span = v_max_global - v_min_global
                margin = max(span * 0.18, 0.15) if span > 0.01 else 0.25
                
                # We globally adapt Y range using EMA per combined graph minimum
                if self.v_min_ema[0] == -1.0: self.v_min_ema[0] = v_min_global - margin
                
                self.v_min_ema[0] = self.v_min_ema[0] * 0.85 + (v_min_global - margin) * 0.15
                self.v_max_ema[0] = self.v_max_ema[0] * 0.85 + (v_max_global + margin) * 0.15
                
                # Y is strictly auto scaled ALWAYS. (X is strictly manual user pan)
                self.canvas.ax1.setYRange(self.v_min_ema[0], self.v_max_ema[0])
                self.canvas.ax2.setYRange(0, yf_max_global * 1.2)

        state = "FROZEN" if is_fully_paused and active_channels else "ACQUIRING"
        ch_str = ",".join(active_channels) if active_channels else "None"
        
        def fmt_v(v): return f"{v*1000:.0f} mV" if abs(v) < 1.0 else f"{v:.2f} V"
        v_range = f"[{fmt_v(v_min_global)}, {fmt_v(v_max_global)}]" if active_channels else ""
        self.status_lbl.setText(f"{state} │ Channels D({ch_str}) │ Vertical Scope: {v_range}")


class WavePreviewWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.setMinimumHeight(45)
        self.wave_type = 0 # 0=Sine, 1=Square, 2=Triangle, 3=Pulse
        
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = self.rect()
        
        painter.setBrush(QColor("#0d1117"))
        painter.setPen(QPen(QColor("#3A3A45"), 1))
        painter.drawRoundedRect(r.adjusted(0, 0, -1, -1), 4, 4)
        
        painter.setPen(QPen(QColor("#58a6ff"), 2))
        path = QPainterPath()
        
        w = float(r.width())
        h = float(r.height())
        cy = h / 2.0
        amp = h * 0.35
        
        if self.wave_type == 0:
            path.moveTo(0, cy)
            period = w / 2.0
            for x in range(int(w)):
                path.lineTo(x, cy - amp * math.sin(2.0 * math.pi * x / period))
                
        elif self.wave_type == 1:
            path.moveTo(0, cy - amp)
            period = w / 2.0
            last_y = cy - amp
            for x in range(int(w)):
                cycle_loc = (x % period) / period
                y = cy - amp if cycle_loc < 0.5 else cy + amp
                if x > 0 and y != last_y:
                    path.lineTo(x, y)
                path.lineTo(x, y)
                last_y = y
                
        elif self.wave_type == 2:
            path.moveTo(0, cy)
            period = w / 2.0
            for x in range(int(w)):
                cycle_loc = (x % period) / period
                if cycle_loc < 0.25: y = cy - amp * (cycle_loc / 0.25)
                elif cycle_loc < 0.75: y = (cy - amp) + amp * 2.0 * ((cycle_loc - 0.25) / 0.5)
                else: y = (cy + amp) - amp * ((cycle_loc - 0.75) / 0.25)
                path.lineTo(x, y)
                
        elif self.wave_type == 3:
            path.moveTo(0, cy)
            period = w / 2.0
            duty = 0.2
            last_y = cy
            for x in range(int(w)):
                cycle_loc = (x % period) / period
                y = cy - amp if cycle_loc < duty else cy
                if x > 0 and y != last_y:
                    path.lineTo(x, y)
                path.lineTo(x, y)
                last_y = y
        
        painter.drawPath(path)

class FuncGenWidget(QWidget):
    def __init__(self, panel=None):
        super().__init__()
        self.panel = panel
        self.backend = InstrumentBackend()
        self.wave_types = ["Sine", "Square", "Triangle", "Pulse"]
        self.comp: VirtualComponent = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0,0,0,0)
        
        self.title = QLabel("FUNCTION GENERATOR (S0)")
        self.title.setObjectName("PanelTitle")
        layout.addWidget(self.title)

        grid = QGridLayout()
        grid.addWidget(QLabel("Frequency (Hz):"), 0, 0)
        self.in_freq = QLineEdit()
        self.in_freq.editingFinished.connect(self.on_freq)
        grid.addWidget(self.in_freq, 0, 1)

        grid.addWidget(QLabel("Vpp (V):"), 1, 0)
        self.in_vpp = QLineEdit()
        self.in_vpp.editingFinished.connect(self.on_vpp)
        grid.addWidget(self.in_vpp, 1, 1)

        grid.addWidget(QLabel("Duty Cycle (%):"), 2, 0)
        self.in_duty = QLineEdit()
        self.in_duty.editingFinished.connect(self.on_duty)
        grid.addWidget(self.in_duty, 2, 1)

        grid.addWidget(QLabel("HW Source:"), 3, 0)
        self.in_source = QComboBox()
        self.in_source.addItems(["Channel A (MCP)"])
        self.in_source.currentIndexChanged.connect(self.on_source)
        grid.addWidget(self.in_source, 3, 1)

        layout.addLayout(grid)

        self.btn_wave = QPushButton("Wave: ")
        self.btn_wave.clicked.connect(self.toggle_wave)
        layout.addWidget(self.btn_wave)
        
        self.preview = WavePreviewWidget()
        layout.addWidget(self.preview)
        
    def refresh_source_combo(self):
        used = set()
        if self.panel and self.panel.board:
            for c in self.panel.board.connection_manager.components:
                if c != self.comp and c.type in ('signal', 'power'):
                    src = c.properties.get('source', 0)
                    used.add(src)
        
        for i in range(1):
            item = self.in_source.model().item(i)
            if item:
                is_used = i in used
                item.setEnabled(not is_used)
                item.setForeground(QBrush(QColor("#6A6A75" if is_used else "#FFFFFF")))
        
    def set_component(self, comp: VirtualComponent):
        self.comp = comp
        self.title.setText(f"FUNCTION GENERATOR (Channel {comp.channel})")
        self.in_freq.setText(str(comp.properties.get('freq', 30.0)))
        self.in_vpp.setText(str(comp.properties.get('vpp', 2.0)))
        self.in_duty.setText(str(comp.properties.get('duty', 50.0)))
        
        w_idx = comp.properties.get('wave', 0)
        self.btn_wave.setText(f"Wave: {self.wave_types[w_idx]}")
        self.in_duty.setEnabled(w_idx == 3)
        self.in_duty.setStyleSheet("" if w_idx == 3 else "color: #555; background-color: #222;")
        
        self.preview.wave_type = w_idx
        self.preview.update()
        
        # Hardware Source
        self.refresh_source_combo()
        src_idx = comp.properties.get('source', 0) # Default to 0
        self.in_source.setCurrentIndex(src_idx)

    def select_channel(self):
        if self.comp:
            self.backend.write_cmd(f"p{self.comp.channel}\n")

    def on_source(self):
        if not self.comp: return
        idx = self.in_source.currentIndex()
        self.comp.properties['source'] = idx
        self.select_channel()
        self.backend.write_cmd(f"S{idx}\n")

    def on_freq(self):
        if not self.comp: return
        try:
            val = max(0.5, min(5000.0, float(self.in_freq.text())))
            self.comp.properties['freq'] = val
            self.select_channel()
            self.backend.write_cmd(f"F{val}\n")
        except ValueError: pass

    def on_vpp(self):
        if not self.comp: return
        try:
            val = max(0.0, min(14.0, float(self.in_vpp.text())))
            self.comp.properties['vpp'] = val
            self.select_channel()
            self.backend.write_cmd(f"V{val}\n")
            self.in_vpp.setText(str(val))
        except ValueError: pass

    def on_duty(self):
        if not self.comp: return
        try:
            val = max(0.0, min(100.0, float(self.in_duty.text())))
            self.comp.properties['duty'] = val
            self.select_channel()
            self.backend.write_cmd(f"D{val}\n")
        except ValueError: pass

    def toggle_wave(self):
        if not self.comp: return
        w_idx = (self.comp.properties.get('wave', 0) + 1) % len(self.wave_types)
        self.comp.properties['wave'] = w_idx
        self.btn_wave.setText(f"Wave: {self.wave_types[w_idx]}")
        self.in_duty.setEnabled(w_idx == 3)
        self.in_duty.setStyleSheet("" if w_idx == 3 else "color: #555; background-color: #222;")
        self.preview.wave_type = w_idx
        self.preview.update()
        self.select_channel()
        self.backend.write_cmd(f"W{w_idx}\n")


class PowerSupplyWidget(QWidget):
    def __init__(self, panel=None):
        super().__init__()
        self.panel = panel
        self.backend = InstrumentBackend()
        self.comp: VirtualComponent = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0,0,0,0)
        
        self.title = QLabel("POWER SUPPLY (P0)")
        self.title.setObjectName("PanelTitle")
        layout.addWidget(self.title)

        # Digital Readout
        self.readout_frame = QFrame()
        self.readout_frame.setStyleSheet("background-color: #0d1117; border: 1px solid #3A3A45; border-radius: 4px;")
        rf_layout = QVBoxLayout(self.readout_frame)
        rf_layout.setContentsMargins(10, 10, 10, 10)
        
        self.lbl_readout = QLabel("0.00 V")
        font = self.lbl_readout.font()
        font.setFamily("Consolas")
        font.setPointSize(24)
        font.setBold(True)
        self.lbl_readout.setFont(font)
        self.lbl_readout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_readout.setStyleSheet("color: #32CD32;") # bright green digital feel
        rf_layout.addWidget(self.lbl_readout)
        layout.addWidget(self.readout_frame)

        # Manual Entry Block
        manual_layout = QHBoxLayout()
        self.in_dc = QLineEdit()
        self.in_dc.setPlaceholderText("e.g. 5.5, -3.2")
        self.in_dc.setStyleSheet("QLineEdit { background: #1F1F24; color: #FFFFFF; border: 1px solid #3A3A45; border-radius: 4px; padding: 6px; font-weight: bold; } QLineEdit:focus { border: 1px solid #E63946; }")
        self.in_dc.returnPressed.connect(self.on_manual_set)
        
        self.btn_set = QPushButton("SET")
        self.btn_set.setStyleSheet("QPushButton { font-weight: bold; background-color: #31313A; color: white; border-radius: 4px; padding: 6px 12px; } QPushButton:hover { background-color: #E63946; } QPushButton:pressed { background-color: #c92a36; }")
        self.btn_set.clicked.connect(self.on_manual_set)
        
        manual_layout.addWidget(QLabel("Manual (V):"))
        manual_layout.addWidget(self.in_dc)
        manual_layout.addWidget(self.btn_set)
        layout.addLayout(manual_layout)

        # Slider Block
        slider_layout = QHBoxLayout()
        self.lbl_min = QLabel("-7V")
        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.setRange(-700, 700) # -7.00 to 7.00
        self.slider.setValue(0)
        self.slider.setTickPosition(QSlider.TickPosition.TicksBelow)
        self.slider.setTickInterval(100)
        self.slider.setStyleSheet("""
            QSlider::groove:horizontal {
                border: 1px solid #3A3A45;
                height: 6px;
                background: #141418;
                margin: 2px 0;
                border-radius: 3px;
            }
            QSlider::handle:horizontal {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #E63946, stop:1 #c92a36);
                border: 1px solid #111;
                width: 14px;
                height: 14px;
                margin: -5px 0;
                border-radius: 7px;
            }
            QSlider::handle:horizontal:hover {
                background: #f74553;
                width: 16px;
                height: 16px;
                margin: -6px 0;
                border-radius: 8px;
            }
            QSlider::sub-page:horizontal {
                background: #E63946;
                border-radius: 3px;
            }
        """)
        self.slider.valueChanged.connect(self.on_slider)
        self.lbl_max = QLabel("+7V")
        
        slider_layout.addWidget(self.lbl_min)
        slider_layout.addWidget(self.slider)
        slider_layout.addWidget(self.lbl_max)
        layout.addLayout(slider_layout)

        # Settings
        grid = QGridLayout()
        grid.addWidget(QLabel("HW Source:"), 0, 0)
        self.in_source = QComboBox()
        self.in_source.addItems(["Channel A (MCP)"])
        self.in_source.currentIndexChanged.connect(self.on_source)
        grid.addWidget(self.in_source, 0, 1)

        layout.addLayout(grid)

    def refresh_source_combo(self):
        used = set()
        if self.panel and self.panel.board:
            for c in self.panel.board.connection_manager.components:
                if c != self.comp and c.type in ('signal', 'power'):
                    src = c.properties.get('source', 0)
                    used.add(src)
        
        for i in range(1):
            item = self.in_source.model().item(i)
            if item:
                is_used = i in used
                item.setEnabled(not is_used)
                item.setForeground(QBrush(QColor("#6A6A75" if is_used else "#FFFFFF")))

    def select_channel(self):
        if self.comp:
            self.backend.write_cmd(f"p{self.comp.channel}\n")

    def on_source(self):
        if not self.comp: return
        idx = self.in_source.currentIndex()
        self.comp.properties['source'] = idx
        self.select_channel()
        self.backend.write_cmd(f"S{idx}\n")

    def set_component(self, comp: VirtualComponent):
        self.comp = comp
        self.title.setText(f"POWER SUPPLY (Channel {comp.channel})")
        
        # Load prev value
        val = comp.properties.get('dc', 0.0)
        self.slider.blockSignals(True)
        self.slider.setValue(int(val * 100))
        self.slider.blockSignals(False)
        self.update_readout(val)
        
        self.refresh_source_combo()
        src_idx = comp.properties.get('source', 0)
        self.in_source.setCurrentIndex(src_idx)

    def update_readout(self, val):
        self.lbl_readout.setText(f"{val:+.2f} V")
        self.in_dc.setText(f"{val:.2f}")
        if val > 0: self.lbl_readout.setStyleSheet("color: #E63946;") # Red for positive
        elif val < 0: self.lbl_readout.setStyleSheet("color: #58a6ff;") # Blue for negative
        else: self.lbl_readout.setStyleSheet("color: #32CD32;") # Green for zero

    def on_manual_set(self):
        if not self.comp: return
        try:
            val = float(self.in_dc.text())
            val = max(-7.0, min(7.0, val))
            self.slider.blockSignals(True)
            self.slider.setValue(int(val * 100))
            self.slider.blockSignals(False)
            self.update_readout(val)
            self.comp.properties['dc'] = val
            self.select_channel()
            self.backend.write_cmd(f"P{val}\n")
        except ValueError:
            pass

    def on_slider(self, slider_val):
        if not self.comp: return
        val = slider_val / 100.0
        self.update_readout(val)
        self.comp.properties['dc'] = val
        self.select_channel()
        self.backend.write_cmd(f"P{val}\n")

class CapacitanceMeterWidget(QWidget):
    def __init__(self, panel=None):
        super().__init__()
        self.panel = panel
        self.backend = InstrumentBackend()
        self.comp: VirtualComponent = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0,0,0,0)
        
        self.title = QLabel("CAPACITANCE METER")
        self.title.setObjectName("PanelTitle")
        layout.addWidget(self.title)

        # Digital Readout
        self.readout_frame = QFrame()
        self.readout_frame.setStyleSheet("background-color: #0d1117; border: 1px solid #3A3A45; border-radius: 4px;")
        rf_layout = QVBoxLayout(self.readout_frame)
        rf_layout.setContentsMargins(10, 10, 10, 10)
        
        self.lbl_readout = QLabel("---")
        font = self.lbl_readout.font()
        font.setFamily("Consolas")
        font.setPointSize(28)
        font.setBold(True)
        self.lbl_readout.setFont(font)
        self.lbl_readout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_readout.setStyleSheet("color: #bb86fc;") 
        rf_layout.addWidget(self.lbl_readout)
        
        self.lbl_sub = QLabel("Raw Touch Sensor Value")
        self.lbl_sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_sub.setStyleSheet("color: #8E8E93; font-size: 11px;")
        rf_layout.addWidget(self.lbl_sub)
        
        layout.addWidget(self.readout_frame)
        layout.addStretch()

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_readout)
        self.timer.start(50)

    def set_component(self, comp: VirtualComponent):
        self.comp = comp

    def update_readout(self):
        if not self.comp or not self.isVisible():
            return
        if not self.backend.is_connected() or not self.backend.data_buffer:
            self.lbl_readout.setText("---")
            return
        
        # Read the latest tuple from buffer
        latest = self.backend.data_buffer[-1]
        if len(latest) >= 3:
            val = latest[2]
            self.lbl_readout.setText(f"{val}")
        else:
            self.lbl_readout.setText("---")


class InstrumentPanel(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("InstrumentPanel")
        self.setMinimumWidth(360)
        self.board = None
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)
        
        self.dso = DsoWidget()
        layout.addWidget(self.dso, 3)
        
        self.prop_container = QFrame()
        self.prop_container.setObjectName("InstrumentContainer")
        self.prop_layout = QVBoxLayout(self.prop_container)
        self.prop_layout.setContentsMargins(12, 12, 12, 12)
        
        self.lbl_empty = QLabel("Double-click a component on the breadboard\nto edit its properties.")
        self.lbl_empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.prop_layout.addWidget(self.lbl_empty)
        
        self.fgen = FuncGenWidget(self)
        self.pps = PowerSupplyWidget(self)
        self.cap_meter = CapacitanceMeterWidget(self)
        self.fgen.hide()
        self.pps.hide()
        self.cap_meter.hide()
        
        self.prop_layout.addWidget(self.fgen)
        self.prop_layout.addWidget(self.pps)
        self.prop_layout.addWidget(self.cap_meter)
        layout.addWidget(self.prop_container, 0)
        
        self.setStyleSheet("""
            QWidget { color: #E0E0E0; }
            #InstrumentPanel { background-color: #121212; }
            #InstrumentContainer {
                background-color: #1A1A1E;
                border: 1px solid #33333C;
                border-radius: 8px;
            }
            QLabel { font-size: 13px; }
            #PanelTitle {
                font-size: 14px;
                font-weight: bold;
                color: #8E8E93;
                letter-spacing: 1px;
            }
            QLineEdit, QComboBox {
                background-color: #25252B;
                border: 1px solid #3A3A45;
                border-radius: 4px;
                padding: 4px;
                color: #FFFFFF;
            }
            QLineEdit:focus, QComboBox:focus { border: 1px solid #E63946; }
            QPushButton {
                background-color: #25252B;
                border: 1px solid #3A3A45;
                border-radius: 4px;
                padding: 6px 10px;
                color: #FFFFFF;
            }
            QPushButton:hover {
                background-color: #31313A;
                border: 1px solid #E63946;
            }
            QPushButton:pressed {
                background-color: #E63946;
                color: white;
            }
        """)

    def on_component_selected(self, comp_id: str):
        if not self.board: return
        comps = [c for c in self.board.connection_manager.components if c.id == comp_id]
        if not comps: return
        comp = comps[0]
        
        self.lbl_empty.hide()
        self.fgen.hide()
        self.pps.hide()
        self.cap_meter.hide()
        
        if comp.type == 'signal':
            self.fgen.set_component(comp)
            self.fgen.show()
        elif comp.type == 'power':
            self.pps.set_component(comp)
            self.pps.show()
        elif comp.type == 'cap_meter':
            self.cap_meter.set_component(comp)
            self.cap_meter.show()
        else:
            self.dso.btn_channels[comp.channel].setChecked(True)
            self.dso.update_channel_visibility()
            self.lbl_empty.setText(f"Probe D{comp.channel} selected.\nAdjust display zoom in the DSO module above.")
            self.lbl_empty.show()
