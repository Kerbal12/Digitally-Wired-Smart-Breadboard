import uuid
from PyQt6.QtGui import QColor
from models import NodeRef, Wire, VirtualComponent, BREADBOARD_ROWS, BREADBOARD_COLS
import time

class ShortCircuitError(Exception):
    pass

class ConnectionManager:
    """Graph-like connection store with 32 Vision-Accessible Colors."""

    BASE_PALETTE = [
        "#56B4E9", "#E69F00", "#CC79A7", "#009E73", "#FFFFFF", "#D55E00", "#F0E442", "#0072B2", 
        "#FFB6C1", "#8A2BE2", "#00FFFF", "#FF4500", "#98FB98", "#C71585", "#7FFF00", "#1E90FF", 
        "#FFA07A", "#32CD32", "#9370DB", "#FF1493", "#40E0D0", "#F08080", "#4682B4", "#DDA0DD", 
        "#BDB76B", "#87CEEB", "#CD853F", "#00FA9A", "#BA55D3", "#F4A460", "#20B2AA", "#FFD700",
    ]

    def __init__(self):
        self.wires: list[Wire] = []
        self.components: list[VirtualComponent] = []

    def clear(self) -> None:
        self.wires.clear()
        self.components.clear()

    def _wire_key(self, a: NodeRef, b: NodeRef) -> tuple[NodeRef, NodeRef]:
        return (a, b) if (a.row, a.col) <= (b.row, b.col) else (b, a)

    def has_wire(self, a: NodeRef, b: NodeRef) -> bool:
        key = self._wire_key(a, b)
        return any(self._wire_key(w.a, w.b) == key for w in self.wires)

    def electrical_id(self, node: NodeRef) -> str:
        if 0 <= node.row <= 4: return f"TOP_TERM_{node.col}"
        if 5 <= node.row <= 9: return f"BOT_TERM_{node.col}"
        if node.row == 10: return "RAIL_TOP_PLUS"
        if node.row == 11: return "RAIL_TOP_MINUS"
        if node.row == 12: return "RAIL_BOT_MINUS"
        if node.row == 13: return "RAIL_BOT_PLUS"
        return f"UNKNOWN_{node.row}_{node.col}"

    def _node_to_number(self, node: NodeRef) -> int:
        if node.row == 10: return 1
        if node.row == 11: return 2
        if 0 <= node.row <= 4: return node.col + 3
        if 5 <= node.row <= 9: return node.col + 33
        if node.row == 12: return 63
        if node.row == 13: return 64
        return -1

    def _get_nets(self) -> list[set[int]]:
        adj = {}
        for w in self.wires:
            num_a = self._node_to_number(w.a)
            num_b = self._node_to_number(w.b)
            if num_a > 0 and num_b > 0:
                adj.setdefault(num_a, set()).add(num_b)
                adj.setdefault(num_b, set()).add(num_a)
                
        visited = set()
        nets = []
        for node in adj:
            if node not in visited:
                net = set()
                stack = [node]
                while stack:
                    curr = stack.pop()
                    if curr not in net:
                        net.add(curr)
                        visited.add(curr)
                        stack.extend(adj.get(curr, []))
                if len(net) > 1:
                    nets.append(net)
        return nets

    def apply_connections(self) -> None:
        try:
            from instrument_backend import InstrumentBackend
            backend = InstrumentBackend()
            if not backend.is_connected(): return
            
            backend.write_cmd("clear\n")
            time.sleep(0.05)
            
            def get_node_priority(n: int) -> int:
                if n in (1, 2, 63, 64): return 0
                for comp in self.components:
                    if self._node_to_number(comp.node) == n:
                        return 1
                return 2
            
            nets = self._get_nets()
            for net in nets:
                sorted_nums = sorted(list(net), key=lambda x: (get_node_priority(x), x))
                primary = sorted_nums[0]
                for other in sorted_nums[1:]:
                    backend.write_cmd(f"{primary:02d}{other:02d}\n")
                    time.sleep(0.01)
                    
            # Route active components to instrument backend pins
            for comp in self.components:
                node_num = self._node_to_number(comp.node)
                if node_num > 0:
                    # Enforce star topology: Route the instrument directly to the network's primary node 
                    # rather than cascading through multiple breadboard wire switches
                    for net in nets:
                        if node_num in net:
                            sorted_nums = sorted(list(net), key=lambda x: (get_node_priority(x), x))
                            node_num = sorted_nums[0]
                            break
                            
                    target_pin = -1
                    if comp.type in ('signal', 'power'):
                        # Using 65-68 for the 4 virtual power/signal pins
                        if comp.channel == 0: target_pin = 65
                        elif comp.channel == 1: target_pin = 66
                        elif comp.channel == 2: target_pin = 67
                        elif comp.channel == 3: target_pin = 68
                    elif comp.type == 'probe':
                        # D1 uses virtual node 69 (Y4 -> Pin 26)
                        # D2 uses virtual node 71 (Y6 -> Pin 34)
                        if comp.channel == 0: target_pin = 69
                        elif comp.channel == 1: target_pin = 71
                    
                    if target_pin > 0:
                        backend.write_cmd(f"{node_num:02d},{target_pin:02d}\n")
                        
                        # Explicitly enforce correct instrument roles so power supplies remain flat DC
                        if comp.type == 'signal':
                            params = f"p{comp.channel}\nF{comp.properties.get('freq', 30.0)}\nV{comp.properties.get('vpp', 2.0)}\nD{comp.properties.get('duty', 50.0)}\nW{comp.properties.get('wave', 0)}\nP{comp.properties.get('dc', 0.0)}\nS{comp.properties.get('source', comp.channel % 4)}\n"
                            backend.write_cmd(params)
                        elif comp.type == 'power':
                            params = f"p{comp.channel}\nV0.0\nP{comp.properties.get('dc', 0.0)}\nS{comp.properties.get('source', comp.channel % 4)}\n"
                            backend.write_cmd(params)
                            
                        time.sleep(0.01)

        except Exception:
            pass

    def component(self, start: NodeRef) -> set[NodeRef]:
        start_id = self.electrical_id(start)
        adj = {}
        for w in self.wires:
            ida = self.electrical_id(w.a)
            idb = self.electrical_id(w.b)
            adj.setdefault(ida, []).append(idb)
            adj.setdefault(idb, []).append(ida)
            
        seen_ids = set()
        stack = [start_id]
        while stack:
            curr_id = stack.pop()
            if curr_id not in seen_ids:
                seen_ids.add(curr_id)
                stack.extend(adj.get(curr_id, []))
                
        result = set()
        for r in range(BREADBOARD_ROWS):
            for c in range(BREADBOARD_COLS):
                n = NodeRef(r, c)
                if self.electrical_id(n) in seen_ids:
                    result.add(n)
        return result

    def _recalculate_network_colors(self) -> None:
        adj = {}
        for w in self.wires:
            ida = self.electrical_id(w.a)
            idb = self.electrical_id(w.b)
            adj.setdefault(ida, []).append(w)
            adj.setdefault(idb, []).append(w)

        visited_wires = set()
        components = []

        for start_wire in self.wires:
            if id(start_wire) not in visited_wires:
                comp_wires = []
                stack = [start_wire]
                while stack:
                    curr_w = stack.pop()
                    if id(curr_w) not in visited_wires:
                        visited_wires.add(id(curr_w))
                        comp_wires.append(curr_w)
                        ida = self.electrical_id(curr_w.a)
                        idb = self.electrical_id(curr_w.b)
                        for neighbor_w in adj.get(ida, []):
                            if id(neighbor_w) not in visited_wires: stack.append(neighbor_w)
                        for neighbor_w in adj.get(idb, []):
                            if id(neighbor_w) not in visited_wires: stack.append(neighbor_w)
                components.append(comp_wires)

        components.sort(key=len, reverse=True)
        used_colors = set()

        for i, comp_wires in enumerate(components):
            color_counts = {}
            for w in comp_wires:
                c_name = w.color.name().upper()
                if c_name not in used_colors:
                    color_counts[c_name] = color_counts.get(c_name, 0) + 1

            # Collect all nodes in this continuous net
            net_nodes = set()
            for w in comp_wires:
                net_nodes.add(w.a)
                net_nodes.add(w.b)
                
            has_8v = any(n.row == 10 for n in net_nodes)
            has_gnd = any(n.row == 13 for n in net_nodes)
            has_neg8v = any(n.row == 12 for n in net_nodes)
            has_fnps = False
            for n in net_nodes:
                c = self.get_component_at(n)
                if c and c.type in ('signal', 'power'):
                    has_fnps = True
                    break

            target_color = None
            if has_8v:
                target_color = "#FF3B30"
            elif has_gnd:
                target_color = "#32CD32" # Green for GND
            elif has_neg8v:
                target_color = "#2E2E36" # A dark, distinct color for -8V
            elif has_fnps:
                target_color = "#4B0082"
            elif color_counts:
                target_color = max(color_counts.items(), key=lambda x: x[1])[0]
            else:
                for base_c in self.BASE_PALETTE:
                    c_upper = base_c.upper()
                    if c_upper not in used_colors:
                        target_color = c_upper
                        break
                if not target_color:
                    target_color = self.BASE_PALETTE[i % 32].upper()

            used_colors.add(target_color)
            net_color = QColor(target_color)
            for w in comp_wires:
                w.color = net_color

    def add_wire(self, a: NodeRef, b: NodeRef, color: QColor) -> bool:
        if self.electrical_id(a) == self.electrical_id(b):
            return False
        if self.has_wire(a, b):
            return False
            
        # Give newly generated wires a natural spread
        wire_hash = (a.row + b.row + a.col + b.col) % 5
        offset = (wire_hash - 2) * 6.0 
        
        self.wires.append(Wire(a, b, color, float(offset)))
        
        try:
            self._validate_no_shorts()
        except Exception as e:
            self.wires.pop()
            raise e
            
        self._recalculate_network_colors()
            
        return True

    def _validate_no_shorts(self) -> None:
        adj = {}
        for w in self.wires:
            ida = self.electrical_id(w.a)
            idb = self.electrical_id(w.b)
            adj.setdefault(ida, set()).add(idb)
            adj.setdefault(idb, set()).add(ida)

        all_ids = set(adj.keys())
        for c in self.components:
            all_ids.add(self.electrical_id(c.node))

        visited = set()
        for start_id in all_ids:
            if start_id in visited: continue
            
            stack = [start_id]
            net_ids = set()
            while stack:
                curr = stack.pop()
                if curr not in visited:
                    visited.add(curr)
                    net_ids.add(curr)
                    for nbr in adj.get(curr, set()):
                        if nbr not in visited:
                            stack.append(nbr)
                            
            has_8v = any(nid == "RAIL_TOP_PLUS" for nid in net_ids)
            has_gnd = any(nid == "RAIL_BOT_PLUS" for nid in net_ids)
            has_neg8v = any(nid == "RAIL_BOT_MINUS" for nid in net_ids)
            
            fnps_count = sum(1 for c in self.components if self.electrical_id(c.node) in net_ids and c.type in ('signal', 'power'))
            rails_mixed = sum((1 if has_8v else 0, 1 if has_gnd else 0, 1 if has_neg8v else 0))
            
            if rails_mixed > 1:
                raise ShortCircuitError("Forbidden: Cannot short power rails (+8V, GND, -8V) together!")
            if fnps_count > 1:
                raise ShortCircuitError("Forbidden: Cannot connect multiple power/function sources directly!")
            if fnps_count > 0 and rails_mixed > 0:
                raise ShortCircuitError("Forbidden: Cannot short function/power sources directly to power rails!")

    def remove_wire(self, a: NodeRef, b: NodeRef) -> bool:
        key = self._wire_key(a, b)
        before = len(self.wires)
        self.wires = [w for w in self.wires if self._wire_key(w.a, w.b) != key]
        if len(self.wires) != before:
            self._recalculate_network_colors()
            return True
        return False

    def remove_node_wires(self, node: NodeRef) -> int:
        before = len(self.wires)
        target_id = self.electrical_id(node)
        self.wires = [w for w in self.wires if self.electrical_id(w.a) != target_id and self.electrical_id(w.b) != target_id]
        removed = before - len(self.wires)
        if removed > 0:
            self._recalculate_network_colors()
        
        # Also remove component if exists at this node
        self.components = [c for c in self.components if c.node != node]
        return removed

    def get_component_at(self, node: NodeRef) -> VirtualComponent | None:
        for c in self.components:
            if c.node == node:
                return c
        return None

    def get_allocated_channels(self, type_group: str) -> list[int]:
        allocated = []
        for c in self.components:
            if type_group == 'output' and c.type in ('signal', 'power'):
                allocated.append(c.channel)
            elif type_group == 'input' and c.type == 'probe':
                allocated.append(c.channel)
        return allocated

    def add_component(self, comp_type: str, node: NodeRef) -> VirtualComponent | None:
        if self.get_component_at(node): return None
        if node.row in (10, 11, 12, 13) and comp_type != 'probe':
            raise ShortCircuitError("Cannot place power/signal Virtual Components directly on power rails!")
            
        t_group = 'input' if comp_type == 'probe' else 'output'
        allocated = self.get_allocated_channels(t_group)
        avail = [i for i in range(2 if t_group == 'input' else 4) if i not in allocated]
        if not avail: return None
        
        ch = avail[0]
        comp = VirtualComponent(id=str(uuid.uuid4()), type=comp_type, node=node, channel=ch)
        if comp_type == 'signal':
            comp.properties = {'freq': 30.0, 'vpp': 2.0, 'duty': 50.0, 'wave': 0}
        elif comp_type == 'power':
            comp.properties = {'dc': 0.0}
        elif comp_type == 'probe':
            comp.properties = {'offset': 0.0, 'scale': 1.0}
            
        self.components.append(comp)
        try:
            self._validate_no_shorts()
        except Exception as e:
            self.components.pop()
            raise e
            
        self._recalculate_network_colors()
        return comp

    def remove_component(self, node: NodeRef) -> bool:
        before = len(self.components)
        self.components = [c for c in self.components if c.node != node]
        return len(self.components) < before

    def node_color(self, node: NodeRef) -> QColor | None:
        target_id = self.electrical_id(node)
        for w in self.wires:
            if self.electrical_id(w.a) == target_id or self.electrical_id(w.b) == target_id:
                return QColor(w.color)
        return None

    def serialize(self) -> dict:
        return {
            "wires": [{"a": [w.a.row, w.a.col], "b": [w.b.row, w.b.col], "color": w.color.name(), "offset": w.route_offset} for w in self.wires],
            "components": [{"id": c.id, "type": c.type, "node": [c.node.row, c.node.col], "channel": c.channel, "props": c.properties} for c in self.components]
        }

    def load(self, payload: dict) -> None:
        self.clear()
        for w in payload.get("wires", []):
            color_str = w.get("color", "#FF3B30")
            offset = w.get("offset", 0.0)
            node_a = NodeRef(w["a"][0], w["a"][1])
            node_b = NodeRef(w["b"][0], w["b"][1])
            self.wires.append(Wire(node_a, node_b, QColor(color_str), offset))
            
        for c in payload.get("components", []):
            node = NodeRef(c["node"][0], c["node"][1])
            comp = VirtualComponent(id=c["id"], type=c["type"], node=node, channel=c["channel"])
            comp.properties = c.get("props", {})
            self.components.append(comp)
            
        self._recalculate_network_colors()