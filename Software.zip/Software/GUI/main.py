import sys
from pathlib import Path
import os
from PyQt6.QtCore import QEasingCurve, QPropertyAnimation, QTimer, Qt, QPoint
from PyQt6.QtGui import QAction, QFont, QPixmap
from PyQt6.QtWidgets import (
    QApplication, QFileDialog, QHBoxLayout, QLabel, QMainWindow,
    QMessageBox, QPushButton, QProgressBar, QSplashScreen, QVBoxLayout, QWidget, 
    QGraphicsOpacityEffect, QFrame, QSplitter, QSpinBox
)

from models import APP_NAME
from widgets import BreadboardWidget, ToolPanel

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(1280, 820)

        root = QWidget()
        self.setCentralWidget(root)
        main_layout = QVBoxLayout(root)
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(10)

        top = QFrame()
        top.setObjectName("TopBar")
        top_layout = QHBoxLayout(top)
        top_layout.setContentsMargins(16, 10, 16, 10)

        title = QLabel(APP_NAME)
        title.setObjectName("AppTitle")
        top_layout.addWidget(title)
        
        self.btn_left_toggle = QPushButton("≡ Tools")
        self.btn_left_toggle.setCursor(Qt.CursorShape.PointingHandCursor)
        top_layout.addWidget(self.btn_left_toggle)
        
        top_layout.addStretch(1)

        self.btn_undo = QPushButton("Undo")
        self.btn_redo = QPushButton("Redo")
        self.btn_save = QPushButton("Save")
        self.btn_load = QPushButton("Load")
        self.btn_clear = QPushButton("Clear Board")

        self.btn_apply = QPushButton("Apply to Hardware")
        self.btn_apply.setStyleSheet("background-color: #009E73; color: white;")

        self.btn_new = QPushButton("New Project")
        self.btn_right_toggle = QPushButton("Inspect ≡")
        
        for b in (self.btn_undo, self.btn_redo, self.btn_save, self.btn_load, self.btn_clear, self.btn_apply, self.btn_new, self.btn_right_toggle):
            if isinstance(b, QPushButton):
                b.setCursor(Qt.CursorShape.PointingHandCursor)
            top_layout.addWidget(b)
            
        main_layout.addWidget(top)

        self.splitter = QSplitter(Qt.Orientation.Horizontal)
        self.splitter.setChildrenCollapsible(True)
        self.splitter.setStyleSheet("""
            QSplitter::handle {
                background-color: #33333C;
                width: 4px;
            }
            QSplitter::handle:hover {
                background-color: #E63946;
            }
        """)

        self.board = BreadboardWidget()
        self.tools = ToolPanel(self.board)
        
        from instrument_widgets import InstrumentPanel
        self.instruments = InstrumentPanel()
        self.instruments.board = self.board
        self.instruments.setMinimumWidth(320)

        self.splitter.addWidget(self.tools)
        self.splitter.addWidget(self.board)
        self.splitter.addWidget(self.instruments)

        self.splitter.setStretchFactor(0, 0)
        self.splitter.setStretchFactor(1, 1)
        self.splitter.setStretchFactor(2, 0)

        main_layout.addWidget(self.splitter, 1)

        self._create_actions()
        self.btn_undo.clicked.connect(self.board.undo)
        self.btn_redo.clicked.connect(self.board.redo)
        self.btn_save.clicked.connect(self.save_project)
        self.btn_load.clicked.connect(self.load_project)
        self.btn_apply.clicked.connect(self.board.apply_connections)
        self.btn_clear.clicked.connect(self.board.clear_board)
        self.btn_new.clicked.connect(self.board.clear_board)
        
        # Toggle Layout logic
        self.btn_left_toggle.clicked.connect(lambda: self.splitter.setSizes([0 if self.splitter.sizes()[0] > 0 else 200, self.splitter.sizes()[1], self.splitter.sizes()[2]]))
        self.btn_right_toggle.clicked.connect(lambda: self.splitter.setSizes([self.splitter.sizes()[0], self.splitter.sizes()[1], 0 if self.splitter.sizes()[2] > 0 else 350]))
        
        self.board.componentDoubleClicked.connect(self.instruments.on_component_selected)
        self.btn_new.clicked.connect(self.board.clear_board)
        self.board.componentDoubleClicked.connect(self.instruments.on_component_selected)
        
        self.statusBar = self.statusBar()
        self.statusBar.setStyleSheet("color: white; font-weight: bold;")
        self.board.fire_error.connect(self.show_error_shake)

        self.setStyleSheet(self._stylesheet())
        self._fade_in()
        
        # Clear matrix on open
        if self.instruments.dso.backend.is_connected():
            self.instruments.dso.backend.write_cmd("clear\n")

    def closeEvent(self, event):
        if self.instruments.dso.backend.is_connected():
            self.instruments.dso.backend.write_cmd("clear\n")
            import time
            time.sleep(0.1) # allow time for transmission
        event.accept()

    def show_error_shake(self, msg: str):
        self.statusBar.showMessage(f"⚠ ERROR: {msg}", 4000)
        self.statusBar.setStyleSheet("QStatusBar { background-color: #E63946; color: white; font-weight: bold; }")
        QTimer.singleShot(4000, lambda: self.statusBar.setStyleSheet("QStatusBar { background-color: transparent; color: white; font-weight: bold; }"))
        
        if hasattr(self.board, 'trigger_glitch'):
            self.board.trigger_glitch()

    def _create_actions(self):
        save_action = QAction("Save Project", self)
        save_action.setShortcut("Ctrl+S")
        save_action.triggered.connect(self.save_project)
        self.addAction(save_action)

        load_action = QAction("Load Project", self)
        load_action.setShortcut("Ctrl+O")
        load_action.triggered.connect(self.load_project)
        self.addAction(load_action)

    def _fade_in(self):
        effect = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(effect)
        anim = QPropertyAnimation(effect, b"opacity", self)
        anim.setDuration(700)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        anim.start()
        self._anim = anim

    def _stylesheet(self) -> str:
        return """
            QWidget {
                background-color: #121212;
                color: #E0E0E0;
                font-family: "Segoe UI", Arial, sans-serif;
                font-size: 14px;
            }
            #TopBar, #ToolPanel {
                background-color: #1A1A1E;
                border: 1px solid #33333C;
                border-radius: 10px;
            }
            #AppTitle {
                font-size: 24px;
                font-weight: bold;
                color: #E63946;
            }
            #PanelTitle {
                font-size: 16px;
                font-weight: bold;
                color: #8E8E93;
                letter-spacing: 1px;
            }
            QPushButton {
                background-color: #25252B;
                border: 1px solid #3A3A45;
                border-radius: 6px;
                padding: 8px 12px;
                color: #FFFFFF;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #31313A;
                border: 1px solid #E63946;
            }
            QPushButton:pressed {
                background-color: #E63946;
                color: white;
            }
        """

    def save_project(self):
        path, _ = QFileDialog.getSaveFileName(self, "Export Matrix", "", "JSON Files (*.json)")
        if path:
            self.board.export_json(Path(path))

    def load_project(self):
        path, _ = QFileDialog.getOpenFileName(self, "Import Matrix", "", "JSON Files (*.json)")
        if path:
            try:
                self.board.import_json(Path(path))
            except Exception as e:
                QMessageBox.warning(self, "Load Error", f"Failed to interface:\n{e}")

class ProfessionalSplashScreen(QSplashScreen):
    def __init__(self):
        super().__init__()
        self.setFixedSize(600, 360)
        self.progress = 0

        screen = QApplication.primaryScreen().geometry()
        self.move(
            int((screen.width() - 600) / 2),
            int((screen.height() - 360) / 2)
        )

        self.container = QWidget(self)
        self.container.setGeometry(0, 0, 600, 360)
        layout = QVBoxLayout(self.container)
        layout.setContentsMargins(40, 40, 40, 40)
        layout.setSpacing(16)
        layout.addStretch(1)

        self.logo = QLabel(self.container)
        self.logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        logo_path = os.path.join(os.path.dirname(__file__), "assets", "LOGO.png")
        if os.path.exists(logo_path):
            pixmap = QPixmap(logo_path)
            self.logo.setPixmap(pixmap.scaledToHeight(120, Qt.TransformationMode.SmoothTransformation))
        else:
            self.logo.setText("🛰️")
            self.logo.setStyleSheet("font-size: 54px;")
            
        layout.addWidget(self.logo)

        self.title = QLabel(APP_NAME, self.container)
        self.title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.title.setStyleSheet("font-size: 32px; font-weight: bold; color: #E63946; font-family: 'Segoe UI', Arial;")
        layout.addWidget(self.title)

        self.subtitle = QLabel("Professional Edition v2.0\nInitializing core modules...", self.container)
        self.subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.subtitle.setWordWrap(True)
        self.subtitle.setStyleSheet("font-size: 14px; color: #8E8E93; font-family: 'Segoe UI', Arial;")
        layout.addWidget(self.subtitle)

        self.bar = QProgressBar(self.container)
        self.bar.setRange(0, 100)
        self.bar.setValue(0)
        self.bar.setFixedHeight(8)
        self.bar.setTextVisible(False)
        self.bar.setStyleSheet(
            "QProgressBar{background:#25252B;border:none;border-radius:4px;}"
            "QProgressBar::chunk{background:#E63946;border-radius:4px;}"
        )
        layout.addWidget(self.bar)
        layout.addStretch(1)
        self.setStyleSheet("background:#121212;")

class App:
    def __init__(self):
        self.qt = QApplication(sys.argv)
        self.qt.setApplicationName(APP_NAME)
        self.qt.setFont(QFont("Segoe UI", 10))

        self.splash = ProfessionalSplashScreen()
        self.main = MainWindow()

    def run(self):
        self.splash.show()
        timer = QTimer()

        def step():
            self.splash.progress = min(100, self.splash.progress + 5)
            self.splash.bar.setValue(self.splash.progress)
            if self.splash.progress >= 100:
                timer.stop()
                self.main.show()
                self.splash.finish(self.main)

        timer.timeout.connect(step)
        timer.start(50)
        sys.exit(self.qt.exec())

if __name__ == "__main__":
    App().run()