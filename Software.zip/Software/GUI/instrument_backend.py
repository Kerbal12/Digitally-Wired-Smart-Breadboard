import serial
import threading
import collections
import time

# ===== CONFIGURATION =====
PORT = "COM3"           # Serial port
PROTOCOL = "csv"        # or "binary"
BAUD_CSV = 921600
BAUD_BINARY = 921600
BUFFER = 2048

INPUT_V_MIN = -9.06
INPUT_V_MAX =  9.06
DAC_VREF = 5.0

# Hardware Calibration Mapping
CALIB_MAP_CH1_XP = [381, 403, 427, 450, 473, 496, 518, 545, 570, 593, 616, 640, 663, 686, 709, 734, 758, 782, 805, 829, 851, 876, 899, 924, 947, 971, 995, 1021, 1048, 1072, 1095, 1118, 1143, 1167, 1192, 1217, 1241, 1265, 1289, 1312, 1337, 1361, 1385, 1409, 1433, 1457, 1480, 1503, 1525, 1552, 1579, 1602, 1625, 1649, 1672, 1695, 1719, 1743, 1767, 1792, 1815, 1839, 1862, 1887, 1911, 1934, 1957, 1981, 2004, 2027, 2053, 2079, 2102, 2124, 2148, 2172, 2196, 2219, 2242, 2266, 2289, 2313, 2337, 2360, 2384, 2408, 2431, 2455, 2479, 2502, 2525, 2549, 2571, 2600, 2623, 2646, 2670, 2694, 2716, 2740, 2763, 2788, 2812, 2836, 2860, 2885, 2910, 2936, 2962, 2986, 3011, 3035, 3061, 3088, 3115, 3140, 3166, 3193, 3220, 3245, 3272, 3299, 3326, 3354, 3382, 3411, 3440, 3470, 3501, 3533, 3568, 3608, 3636, 3638, 3639]
CALIB_MAP_CH1_YP = [-7.0, -6.5, -6.4, -6.3, -6.2, -6.1, -6.0, -5.9, -5.8, -5.7, -5.6, -5.5, -5.4, -5.3, -5.2, -5.1, -5.0, -4.9, -4.8, -4.7, -4.6, -4.5, -4.4, -4.3, -4.2, -4.1, -4.0, -3.9, -3.8, -3.7, -3.6, -3.5, -3.4, -3.3, -3.2, -3.1, -3.0, -2.9, -2.8, -2.7, -2.6, -2.5, -2.4, -2.3, -2.2, -2.1, -2.0, -1.9, -1.8, -1.7, -1.6, -1.5, -1.4, -1.3, -1.2, -1.1, -1.0, -0.9, -0.8, -0.7, -0.6, -0.5, -0.4, -0.3, -0.2, -0.1, -0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0, 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0, 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7, 3.8, 3.9, 4.0, 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7, 4.8, 4.9, 5.0, 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 5.7, 5.8, 5.9, 6.0, 6.1, 6.2, 6.3, 6.4, 6.5, 6.6, 6.7, 6.8]
CALIB_MAP_CH2_XP = [379, 378, 400, 424, 448, 471, 493, 516, 544, 567, 590, 614, 638, 661, 684, 707, 732, 756, 779, 803, 827, 850, 873, 897, 922, 945, 968, 993, 1019, 1045, 1070, 1092, 1116, 1141, 1166, 1190, 1215, 1239, 1263, 1287, 1311, 1335, 1359, 1383, 1407, 1432, 1455, 1478, 1502, 1524, 1550, 1578, 1600, 1623, 1647, 1670, 1694, 1717, 1742, 1765, 1790, 1814, 1838, 1861, 1885, 1909, 1933, 1956, 1980, 2003, 2026, 2051, 2077, 2101, 2124, 2147, 2171, 2194, 2218, 2242, 2265, 2288, 2312, 2336, 2359, 2383, 2407, 2431, 2454, 2477, 2501, 2524, 2548, 2570, 2600, 2623, 2646, 2669, 2692, 2716, 2740, 2763, 2787, 2811, 2835, 2860, 2885, 2910, 2936, 2961, 2986, 3010, 3035, 3061, 3088, 3115, 3140, 3166, 3192, 3219, 3245, 3272, 3299, 3326, 3354, 3382, 3411, 3440, 3470, 3501, 3534, 3568, 3608, 3637, 3638, 3639]
CALIB_MAP_CH2_YP = [-7.0, -6.7, -6.5, -6.4, -6.3, -6.2, -6.1, -6.0, -5.9, -5.8, -5.7, -5.6, -5.5, -5.4, -5.3, -5.2, -5.1, -5.0, -4.9, -4.8, -4.7, -4.6, -4.5, -4.4, -4.3, -4.2, -4.1, -4.0, -3.9, -3.8, -3.7, -3.6, -3.5, -3.4, -3.3, -3.2, -3.1, -3.0, -2.9, -2.8, -2.7, -2.6, -2.5, -2.4, -2.3, -2.2, -2.1, -2.0, -1.9, -1.8, -1.7, -1.6, -1.5, -1.4, -1.3, -1.2, -1.1, -1.0, -0.9, -0.8, -0.7, -0.6, -0.5, -0.4, -0.3, -0.2, -0.1, -0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0, 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0, 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7, 3.8, 3.9, 4.0, 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7, 4.8, 4.9, 5.0, 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 5.7, 5.8, 5.9, 6.0, 6.1, 6.2, 6.3, 6.4, 6.5, 6.6, 6.7, 6.8]

FS_CSV = 1000
FS_BINARY = 4000

if PROTOCOL == "csv":
    BAUD = BAUD_CSV
    FS = FS_CSV
else:
    BAUD = BAUD_BINARY
    FS = FS_BINARY

class InstrumentBackend:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(InstrumentBackend, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
            
        self._initialized = True
        self.ser = None
        self.data_buffer = collections.deque([(0, 0, 0, 0)] * BUFFER, maxlen=BUFFER)
        self.sample_times = collections.deque(maxlen=500)
        self.estimated_fs = float(FS)
        self.ser_lock = threading.Lock()
        self.bin_ch = -1
        self.bin_row = [0, 0, 0, 0]
        
        # Connect
        try:
            self.ser = serial.Serial(PORT, BAUD, timeout=0.1)
        except Exception as e:
            print(f"Warning: Could not open port {PORT}. Running UI in disconnected mode.")

        # Start listening thread
        if PROTOCOL == "csv":
            self.thread = threading.Thread(target=self._read_serial_csv, daemon=True)
        else:
            self.thread = threading.Thread(target=self._read_serial_binary, daemon=True)
        self.thread.start()

    def _read_serial_csv(self):
        while True:
            if self.ser is None:
                time.sleep(0.1)
                continue
            try:
                line = self.ser.readline().decode("utf-8", errors="ignore").strip()
                if not line:
                    continue
                parts = line.split(",")
                if parts:
                    row = [0, 0, 0, 0]
                    for i in range(min(4, len(parts))):
                        try:
                            v = int(parts[i])
                            row[i] = v if 0 <= v <= 4095 else 0
                        except ValueError:
                            pass
                    self.data_buffer.append(tuple(row))
                    
                    t = time.perf_counter()
                    self.sample_times.append(t)
                    if len(self.sample_times) >= 200:
                        dt = self.sample_times[-1] - self.sample_times[0]
                        if dt > 0:
                            self.estimated_fs = (len(self.sample_times) - 1) / dt
            except Exception:
                pass

    def _read_serial_binary(self):
        high_byte = None
        while True:
            if self.ser is None:
                time.sleep(0.1)
                continue
            try:
                waiting = self.ser.in_waiting
                if waiting > 0:
                    chunk = self.ser.read(waiting)
                    for b in chunk:
                        if b & 0x80:
                            high_byte = b
                        elif high_byte is not None:
                            val = ((high_byte & 0x3F) << 6) | (b & 0x3F)
                            self.bin_ch += 1
                            if self.bin_ch >= 4:
                                self.bin_ch = 0
                                self.bin_row = [0, 0, 0, 0]
                            self.bin_row[self.bin_ch] = val
                            if self.bin_ch == 3:
                                self.data_buffer.append(tuple(self.bin_row))
                            high_byte = None
            except Exception:
                pass

    def write_cmd(self, cmd: str):
        """Thread-safe way to write command to serial"""
        if self.ser is not None and self.ser.is_open:
            with self.ser_lock:
                try:
                    self.ser.write(cmd.encode("utf-8"))
                except Exception as e:
                    print(f"Error writing to {PORT}: {e}")

    def is_connected(self) -> bool:
        return self.ser is not None and self.ser.is_open
