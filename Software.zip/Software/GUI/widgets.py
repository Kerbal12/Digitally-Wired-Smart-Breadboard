import math
from PyQt6.QtCore import QPointF, QRectF, QTimer, Qt, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen, QCursor, QLinearGradient, QRadialGradient, QPolygonF
from PyQt6.QtWidgets import QWidget, QFrame, QVBoxLayout, QLabel, QPushButton, QSizePolicy

from models import NodeRef, Wire, BREADBOARD_COLS, BREADBOARD_ROWS, VirtualComponent
from connection_manager import ConnectionManager

def draw_custom_icon(painter: QPainter, cx: float, cy: float, icon_type: str, base_color: QColor):
    if icon_type == "select":
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.setPen(QPen(QColor("#FFFFFF"), 1.5, Qt.PenStyle.DashLine))
        painter.drawRect(QRectF(cx - 12, cy - 12, 20, 20))
        painter.setPen(QPen(QColor("#58a6ff"), 1.5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
        painter.setBrush(QColor("#58a6ff"))
        arrow = QPainterPath()
        arrow.moveTo(cx + 4, cy + 4)
        arrow.lineTo(cx + 4, cy + 16)
        arrow.lineTo(cx + 8, cy + 12)
        arrow.lineTo(cx + 12, cy + 18)
        arrow.lineTo(cx + 14, cy + 16)
        arrow.lineTo(cx + 10, cy + 10)
        arrow.lineTo(cx + 16, cy + 10)
        arrow.lineTo(cx + 4, cy + 4)
        painter.drawPath(arrow)

    elif icon_type == "wire":
        path = QPainterPath()
        path.moveTo(cx - 10, cy + 6)
        path.cubicTo(cx - 10, cy - 12, cx + 5, cy - 12, cx + 5, cy - 2)
        path.cubicTo(cx + 5, cy + 8, cx - 5, cy + 10, cx - 5, cy + 2)
        path.cubicTo(cx - 5, cy - 5, cx + 12, cy - 5, cx + 12, cy + 8)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.setPen(QPen(QColor("#FFFFFF"), 1.5))
        painter.drawPath(path)
        painter.setBrush(QColor("#E63946"))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(QPointF(cx - 10, cy + 6), 2.5, 2.5)
        painter.setBrush(QColor("#58a6ff"))
        painter.drawEllipse(QPointF(cx + 12, cy + 8), 2.5, 2.5)

    elif icon_type == "eraser":
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.setPen(QPen(QColor("#FFFFFF"), 1.8, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
        painter.drawLine(int(cx - 8), int(cy - 6), int(cx + 8), int(cy - 6))
        painter.drawLine(int(cx - 3), int(cy - 6), int(cx - 2), int(cy - 9))
        painter.drawLine(int(cx + 3), int(cy - 6), int(cx + 2), int(cy - 9))
        painter.drawLine(int(cx - 2), int(cy - 9), int(cx + 2), int(cy - 9))
        painter.drawLine(int(cx - 6), int(cy - 6), int(cx - 4), int(cy + 8))
        painter.drawLine(int(cx + 6), int(cy - 6), int(cx + 4), int(cy + 8))
        painter.drawLine(int(cx - 4), int(cy + 8), int(cx + 4), int(cy + 8))
        painter.drawLine(int(cx - 2), int(cy - 2), int(cx - 1), int(cy + 5))
        painter.drawLine(int(cx + 2), int(cy - 2), int(cx + 1), int(cy + 5))

    elif icon_type == "signal" or icon_type == "place_signal":
        painter.setBrush(QColor("#121212"))
        painter.setPen(QPen(QColor("#8E8E93"), 1.5))
        painter.drawRoundedRect(QRectF(cx - 12, cy - 10, 24, 20), 2, 2)
        wave = QPainterPath()
        wave.moveTo(cx - 10, cy)
        for i in range(21):
            dx = i - 10
            wave.lineTo(cx + dx, cy - 5 * math.sin(dx * math.pi / 5.0))
        painter.setPen(QPen(base_color, 1.2))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawPath(wave)

    elif icon_type == "power" or icon_type == "place_power":
        painter.setBrush(QColor("#121212"))
        painter.setPen(QPen(QColor("#FFFFFF"), 1.5))
        painter.drawRoundedRect(QRectF(cx - 8, cy - 12, 16, 24), 2, 2)
        painter.setBrush(QColor("#FFFFFF"))
        painter.drawRoundedRect(QRectF(cx - 3, cy - 15, 6, 3), 1, 1)
        painter.setPen(QPen(QColor("#E63946"), 1.5))
        painter.drawLine(int(cx - 3), int(cy - 5), int(cx + 3), int(cy - 5))
        painter.drawLine(int(cx), int(cy - 8), int(cx), int(cy - 2))
        painter.setPen(QPen(QColor("#58a6ff"), 1.5))
        painter.drawLine(int(cx - 3), int(cy + 6), int(cx + 3), int(cy + 6))

    elif icon_type == "probe" or icon_type == "place_probe":
        painter.save()
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        
        painter.translate(cx, cy - 1.0)
        painter.scale(0.80, 0.80)
        painter.rotate(-45)
        
        # Cable Hook
        path = QPainterPath()
        path.moveTo(6.5, 0)
        path.cubicTo(9, 0, 9, 6, 2, 8)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.setPen(QPen(QColor("#8E8E93"), 1.8, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        painter.drawPath(path)
        
        # Metal Needle
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor("#FFFFFF"))
        painter.drawPolygon(QPolygonF([QPointF(-11, 0), QPointF(-7, -0.6), QPointF(-7, 0.6)]))
        
        # Tapered Cone Neck
        painter.setBrush(QColor("#A0A0A5"))
        painter.drawPolygon(QPolygonF([QPointF(-7, -0.8), QPointF(-3, -2.0), QPointF(-3, 2.0), QPointF(-7, 0.8)]))
        
        # Identifying Colored Band
        painter.setBrush(base_color)
        painter.drawRect(QRectF(-3, -2.2, 1.5, 4.4))
        
        # Cylindrical Main Grip / Body
        body_grad = QLinearGradient(0, -2.5, 0, 2.5)
        body_grad.setColorAt(0.0, QColor("#C0C0C5"))
        body_grad.setColorAt(0.3, QColor("#FFFFFF")) # Specular top reflection
        body_grad.setColorAt(1.0, QColor("#808085"))
        painter.setBrush(body_grad)
        painter.setPen(QPen(QColor("#404040"), 0.5))
        painter.drawRoundedRect(QRectF(-1.5, -2.5, 8.0, 5.0), 1.0, 1.0)
        
        # Hand-grip Ribbing Details
        painter.setPen(QPen(QColor("#6A6A70"), 1.0))
        for i in range(1, 6):
            rx = -1.5 + i * 1.2
            painter.drawLine(QPointF(rx, -2.0), QPointF(rx, 2.0))
        
        # Rubber Strain Relief (Tail)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor("#8E8E93"))
        painter.drawPolygon(QPolygonF([QPointF(6.5, -2.0), QPointF(8.5, -1.0), QPointF(8.5, 1.0), QPointF(6.5, 2.0)]))
        
        painter.restore()

class BreadboardWidget(QWidget):
    COLS = BREADBOARD_COLS
    ROWS = BREADBOARD_ROWS
    componentDoubleClicked = pyqtSignal(str)
    fire_error = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(760, 640)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.connection_manager = ConnectionManager()
        self.tool = "wire"
        self.wire_color = QColor("#D32F2F")
        
        self.start_node: NodeRef | None = None
        self.hover_node: NodeRef | None = None
        self.hover_wire: Wire | None = None  
        self.selected_network: set[NodeRef] | None = None
        self.selected_wire: Wire | None = None 
        
        # State for interactive wire dragging
        self.dragging_wire: Wire | None = None
        self.last_mouse_pos: QPointF | None = None
        
        self.drag_select_start: QPointF | None = None
        self.drag_select_current: QPointF | None = None
        self.selected_items = []
        
        self.pulse = 0.0
        self.glitch_timer = 0

        self.anim_timer = QTimer(self)
        self.anim_timer.timeout.connect(self._tick)
        self.anim_timer.start(30)

        self.undo_stack: list[dict] = []
        self.redo_stack: list[dict] = []

    def set_tool(self, tool: str):
        self.tool = tool
        self.start_node = None
        self.selected_network = None
        self.selected_wire = None
        self.dragging_wire = None
        self.setCursor(Qt.CursorShape.ArrowCursor)
        self.update()

    def save_state(self):
        self.undo_stack.append(self.connection_manager.serialize())
        if len(self.undo_stack) > 50:
            self.undo_stack.pop(0)
        self.redo_stack.clear()

    def undo(self):
        if not self.undo_stack: return
        self.redo_stack.append(self.connection_manager.serialize())
        self.connection_manager.load(self.undo_stack.pop())
        self.start_node = None
        self.selected_network = None
        self.selected_wire = None
        self.dragging_wire = None
        self.update()

    def redo(self):
        if not self.redo_stack: return
        self.undo_stack.append(self.connection_manager.serialize())
        self.connection_manager.load(self.redo_stack.pop())
        self.start_node = None
        self.selected_network = None
        self.selected_wire = None
        self.dragging_wire = None
        self.update()

    def clear_board(self):
        self.save_state()
        self.connection_manager.clear()
        self.start_node = None
        self.selected_network = None
        self.selected_wire = None
        self.dragging_wire = None
        self.update()

    def export_json(self, path) -> None:
        import json
        with open(path, 'w') as f:
            json.dump(self.connection_manager.serialize(), f, indent=4)

    def import_json(self, path) -> None:
        import json
        with open(path, 'r') as f:
            data = json.load(f)
        self.save_state()
        self.connection_manager.load(data)
        self.start_node = None
        self.selected_network = None
        self.selected_wire = None
        self.dragging_wire = None
        self.update()

    def apply_connections(self) -> None:
        self.connection_manager.apply_connections()

    def _board_rect(self) -> QRectF:
        margin = 48
        return QRectF(margin, margin, self.width() - 2 * margin, self.height() - 2 * margin)

    def _geom(self) -> dict:
        rect = self._board_rect()
        h = rect.height()
        w = rect.width()

        pad_x = w * 0.05
        x_left = rect.left() + pad_x
        x_right = rect.right() - pad_x
        term_w = x_right - x_left
        term_x = [x_left + i * (term_w / (self.COLS - 1)) for i in range(self.COLS)]

        top_plus_y = rect.top() + h * 0.09
        top_minus_y = rect.top() + h * 0.16
        
        top_a = rect.top() + h * 0.28
        top_e = rect.top() + h * 0.43
        top_row_y = [top_a + r * ((top_e - top_a) / 4) for r in range(5)]

        trench_top = rect.top() + h * 0.46
        trench_bottom = rect.top() + h * 0.54

        bot_f = rect.top() + h * 0.57
        bot_j = rect.top() + h * 0.72
        bot_row_y = [bot_f + r * ((bot_j - bot_f) / 4) for r in range(5)]

        bot_plus_y = rect.top() + h * 0.84
        bot_minus_y = rect.top() + h * 0.91

        stripe_top_plus = top_plus_y - 12
        stripe_top_minus = top_minus_y + 12
        stripe_bot_plus = bot_plus_y - 12
        stripe_bot_minus = bot_minus_y + 12

        return {
            "rect": rect, "x_left": x_left, "x_right": x_right, "term_x": term_x,
            "top_row_y": top_row_y, "bot_row_y": bot_row_y,
            "trench_top": trench_top, "trench_bottom": trench_bottom,
            "top_plus_y": top_plus_y, "top_minus_y": top_minus_y,
            "bot_plus_y": bot_plus_y, "bot_minus_y": bot_minus_y,
            "stripe_top_plus": stripe_top_plus, "stripe_top_minus": stripe_top_minus,
            "stripe_bot_plus": stripe_bot_plus, "stripe_bot_minus": stripe_bot_minus,
        }

    def _node_pos(self, node: NodeRef) -> QPointF:
        g = self._geom()
        if 0 <= node.row <= 4: y = g["top_row_y"][node.row]
        elif 5 <= node.row <= 9: y = g["bot_row_y"][node.row - 5]
        elif node.row == 10: y = g["top_plus_y"]
        elif node.row == 11: y = g["top_minus_y"]
        elif node.row == 12: y = g["bot_plus_y"]
        else: y = g["bot_minus_y"]
        return QPointF(g["term_x"][node.col], y)

    def _nearest_node(self, p: QPointF) -> NodeRef | None:
        best = None
        best_d = 1e9
        for r in range(self.ROWS):
            for c in range(self.COLS):
                n = NodeRef(r, c)
                pos = self._node_pos(n)
                d = math.hypot(pos.x() - p.x(), pos.y() - p.y())
                if d < best_d:
                    best_d = d
                    best = n
        return best if best_d <= 24 else None

    def _distance_point_to_segment(self, p: QPointF, a: QPointF, b: QPointF) -> float:
        abx, aby = b.x() - a.x(), b.y() - a.y()
        apx, apy = p.x() - a.x(), p.y() - a.y()
        ab2 = abx * abx + aby * aby
        if ab2 == 0: return math.hypot(apx, apy)
        t = max(0.0, min(1.0, (apx * abx + apy * aby) / ab2))
        proj = QPointF(a.x() + t * abx, a.y() + t * aby)
        return math.hypot(p.x() - proj.x(), p.y() - proj.y())

    def _nearest_wire(self, p: QPointF) -> Wire | None:
        nearest = None
        dist = 1e9
        for w in self.connection_manager.wires:
            pts = self._get_wire_points(w)
            for i in range(len(pts) - 1):
                d = self._distance_point_to_segment(p, pts[i], pts[i+1])
                if d < dist:
                    dist = d
                    nearest = w
        return nearest if nearest and dist <= 12 else None

    def _get_hits(self, pos: QPointF, ignore_wires: bool = False) -> tuple[NodeRef | None, Wire | None]:
        node = self._nearest_node(pos)
        
        if ignore_wires:
            return node, None

        wire = self._nearest_wire(pos)

        if node and wire:
            n_pos = self._node_pos(node)
            d_node = math.hypot(n_pos.x() - pos.x(), n_pos.y() - pos.y())

            if d_node <= 8.0:
                return node, None

            d_wire = 1e9
            pts = self._get_wire_points(wire)
            for i in range(len(pts) - 1):
                d = self._distance_point_to_segment(pos, pts[i], pts[i+1])
                if d < d_wire: 
                    d_wire = d

            if d_wire < d_node:
                node = None
            else:
                wire = None

        return node, wire

    def _get_wire_points(self, w: Wire) -> list[QPointF]:
        a_pt = self._node_pos(w.a)
        b_pt = self._node_pos(w.b)
        if w.a == w.b: return [a_pt, b_pt]

        g = self._geom()
        col_w = g["term_x"][1] - g["term_x"][0] if self.COLS > 1 else 20
        offset = w.route_offset 
       
        if w.a.col == w.b.col:
            dir_x = 1 if w.a.col < self.COLS / 2 else -1
            cx = a_pt.x() + dir_x * (col_w * 0.4) + offset
            return [a_pt, QPointF(cx, a_pt.y()), QPointF(cx, b_pt.y()), b_pt]

        if abs(w.a.col - w.b.col) == 1:
            mid_x = (a_pt.x() + b_pt.x()) / 2 + offset
            return [a_pt, QPointF(mid_x, a_pt.y()), QPointF(mid_x, b_pt.y()), b_pt]

        dir_x = 1 if b_pt.x() > a_pt.x() else -1
        cx1 = a_pt.x() + dir_x * (col_w * 0.4) + offset
        cx2 = b_pt.x() - dir_x * (col_w * 0.4) - offset

        bump_dir = -1 if w.a.row == w.b.row and (w.a.row <= 4 or w.a.row in (10, 11)) else 1 if w.b.row > w.a.row else -1
        cy = a_pt.y() + (11 * bump_dir) + offset

        return [a_pt, QPointF(cx1, a_pt.y()), QPointF(cx1, cy), QPointF(cx2, cy), QPointF(cx2, b_pt.y()), b_pt]

    def _build_wire_path(self, w: Wire) -> QPainterPath:
        pts = self._get_wire_points(w)
        path = QPainterPath()
        if not pts: return path
        
        path.moveTo(pts[0])
        radius = 12.0 
        
        for i in range(1, len(pts) - 1):
            p_prev, p_curr, p_next = pts[i-1], pts[i], pts[i+1]
            v1_x, v1_y = p_prev.x() - p_curr.x(), p_prev.y() - p_curr.y()
            v2_x, v2_y = p_next.x() - p_curr.x(), p_next.y() - p_curr.y()
            l1, l2 = math.hypot(v1_x, v1_y), math.hypot(v2_x, v2_y)
             
            if l1 < 0.1 or l2 < 0.1:
                path.lineTo(p_curr)
                continue
                
            r = min(radius, l1 / 2.1, l2 / 2.1)
            start_p = QPointF(p_curr.x() + (v1_x / l1) * r, p_curr.y() + (v1_y / l1) * r)
            end_p = QPointF(p_curr.x() + (v2_x / l2) * r, p_curr.y() + (v2_y / l2) * r)
            
            path.lineTo(start_p)
            path.quadTo(p_curr, end_p)
            
        path.lineTo(pts[-1])
        return path

    def mouseMoveEvent(self, event):
        pos = event.position()

        is_routing = self.tool == "wire" and getattr(self, 'start_node', None) is not None
        self.hover_node, self.hover_wire = self._get_hits(pos, ignore_wires=is_routing)

        if getattr(self, 'moving_component', None) and self.hover_node:
            self.moving_component.node = self.hover_node
            self.setCursor(Qt.CursorShape.ClosedHandCursor)
            self.update()
            return

        if getattr(self, 'moving_wire_end', None) and self.hover_node:
            wire, end = self.moving_wire_end
            if end == 'a': wire.a = self.hover_node
            else: wire.b = self.hover_node
            self.setCursor(Qt.CursorShape.ClosedHandCursor)
            self.update()
            return

        if getattr(self, 'drag_select_start', None):
            self.drag_select_current = pos
            self.update()
            return
            
        # Interactive Dragging Logic
        if getattr(self, 'dragging_wire', None):
            self.setCursor(Qt.CursorShape.ClosedHandCursor)
            w = self.dragging_wire
            
            # Translate mouse movement into the physical wire routing axis
            if w.a.col == w.b.col or abs(w.a.col - w.b.col) == 1:
                delta = pos.x() - self.last_mouse_pos.x()
            else:
                delta = pos.y() - self.last_mouse_pos.y()
            
            w.route_offset += delta
            self.last_mouse_pos = pos
            self.update()
            return



        # Highlight hovered items unless dragging selection
        if not self.drag_select_start:
            if self.tool == "eraser":
                has_wire = self.hover_node and self.connection_manager.node_color(self.hover_node)
                if has_wire or self.hover_wire:
                    self.setCursor(Qt.CursorShape.PointingHandCursor) 
                else:
                    self.setCursor(Qt.CursorShape.CrossCursor) 
        elif self.tool in ("place_signal", "place_power", "place_probe"):
            if self.hover_node:
                self.setCursor(Qt.CursorShape.PointingHandCursor)
            else:
                self.setCursor(Qt.CursorShape.CrossCursor)
        elif self.tool in ("select", "wire"):
            is_occupied = False
            if self.hover_node:
                is_occupied = bool(self.connection_manager.get_component_at(self.hover_node)) or any(w.a == self.hover_node or w.b == self.hover_node for w in self.connection_manager.wires)
            
            if getattr(self, 'start_node', None) is None and is_occupied:
                self.setCursor(Qt.CursorShape.OpenHandCursor)
            elif self.tool == "wire" and (self.hover_node or self.hover_wire):
                self.setCursor(Qt.CursorShape.PointingHandCursor)
            elif self.tool == "select":
                self.setCursor(Qt.CursorShape.ArrowCursor)
            else:
                self.setCursor(Qt.CursorShape.CrossCursor) 

        self.update()

    def leaveEvent(self, event):
        self.hover_node = None
        self.hover_wire = None
        self.dragging_wire = None
        self.setCursor(Qt.CursorShape.ArrowCursor)
        self.update()

    def mousePressEvent(self, event):
        self.setFocus()
        if event.button() == Qt.MouseButton.RightButton:
            self.start_node = None
            self.selected_network = None
            self.selected_wire = None
            self.dragging_wire = None
            self.moving_component = None
            self.moving_wire_end = None
            self.update()
            return

        if event.button() != Qt.MouseButton.LeftButton:
            return
            
        is_routing = self.tool == "wire" and getattr(self, 'start_node', None) is not None
        clicked_node, near_wire = self._get_hits(event.position(), ignore_wires=is_routing)

        if getattr(self, 'start_node', None) is None and self.tool == "select":
            if clicked_node:
                comp = self.connection_manager.get_component_at(clicked_node)
                if comp:
                    self.save_state()
                    self.moving_component = comp
                    self.moving_original_node = clicked_node
                    self.setCursor(Qt.CursorShape.ClosedHandCursor)
                    return
                for w in reversed(self.connection_manager.wires):
                    if w.a == clicked_node:
                        self.save_state()
                        self.moving_wire_end = (w, 'a')
                        self.moving_original_node = clicked_node
                        self.setCursor(Qt.CursorShape.ClosedHandCursor)
                        return
                    elif w.b == clicked_node:
                        self.save_state()
                        self.moving_wire_end = (w, 'b')
                        self.moving_original_node = clicked_node
                        self.setCursor(Qt.CursorShape.ClosedHandCursor)
                        return
            
            self.drag_select_start = event.position()
            self.drag_select_current = event.position()
            self.selected_items = []
            self.update()
            return

        if self.tool == "eraser":
            self.save_state()
            if clicked_node:
                self.connection_manager.remove_node_wires(clicked_node)
            elif near_wire:
                self.connection_manager.remove_wire(near_wire.a, near_wire.b)
            self.start_node = None
            self.selected_network = None
            self.selected_wire = None
            self.dragging_wire = None
            self.update()
            return

        if self.tool in ("place_signal", "place_power", "place_probe"):
            if clicked_node:
                self.save_state()
                comp_type = self.tool.split("_")[1]
                try:
                    comp = self.connection_manager.add_component(comp_type, clicked_node)
                    if not comp:
                        print(f"Cannot place {comp_type} (node occupied or hardware max channels reached)")
                except Exception as e:
                    self.undo()
                    self.fire_error.emit(str(e))
            self.update()
            return

        # Wire Tool Interactions
        if self.start_node is None:
            if clicked_node:
                self.start_node = clicked_node
                self.selected_network = None
                self.selected_wire = None
                self.dragging_wire = None
            elif near_wire:
                # Capture the exact wire object for interactive dragging
                self.save_state()
                self.selected_network = self.connection_manager.component(near_wire.a)
                self.selected_wire = near_wire
                self.dragging_wire = near_wire
                self.last_mouse_pos = event.position()
            else:
                self.selected_network = None
                self.selected_wire = None
                self.dragging_wire = None
                self.selected_network = None
                self.selected_wire = None
                self.dragging_wire = None
        else:
            if clicked_node:
                self.save_state()
                try:
                    self.connection_manager.add_wire(self.start_node, clicked_node, self.wire_color)
                    self.selected_network = self.connection_manager.component(clicked_node)
                    self.selected_wire = None
                except Exception as e:
                    self.undo()
                    self.fire_error.emit(str(e))
            else:
                self.selected_network = None
                self.selected_wire = None
            self.start_node = None
            self.dragging_wire = None
            
        self.update()
        
    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            if getattr(self, 'moving_component', None):
                comp = self.moving_component
                target = comp.node
                
                revert = False
                existing = self.connection_manager.get_component_at(target)
                if existing and existing != comp:
                    revert = True
                
                if not revert:
                    try:
                        self.connection_manager._validate_no_shorts()
                        self.connection_manager._recalculate_network_colors()
                        self.connection_manager.apply_connections()
                    except Exception as e:
                        revert = True
                        self.fire_error.emit(str(e))
                        
                if revert:
                    comp.node = self.moving_original_node
                    
                self.moving_component = None
                self.moving_original_node = None
                self.setCursor(Qt.CursorShape.ArrowCursor)
                self.update()
                return

            if getattr(self, 'moving_wire_end', None):
                self.moving_wire_end = None
                self.moving_original_node = None
                self.setCursor(Qt.CursorShape.ArrowCursor)
                self.connection_manager.apply_connections()
                self.update()
                return

            if getattr(self, 'dragging_wire', None):
                self.dragging_wire = None
                self.setCursor(Qt.CursorShape.PointingHandCursor)
                self.connection_manager.apply_connections()
                self.update()
            elif getattr(self, 'drag_select_start', None):
                r = QRectF(self.drag_select_start, self.drag_select_current).normalized()
                self.selected_items = []
                
                for w in self.connection_manager.wires:
                    if r.contains(self._node_pos(w.a)) and r.contains(self._node_pos(w.b)):
                        self.selected_items.append(w)
                for c in self.connection_manager.components:
                    if r.contains(self._node_pos(c.node)):
                        self.selected_items.append(c)
                        
                self.drag_select_start = None
                self.drag_select_current = None
                self.update()

    def keyPressEvent(self, event):
        if event.modifiers() == Qt.KeyboardModifier.ControlModifier:
            if event.key() == Qt.Key.Key_Z:
                self.undo()
                return
            elif event.key() == Qt.Key.Key_Y:
                self.redo()
                return
                
        if event.key() == Qt.Key.Key_Delete or event.key() == Qt.Key.Key_Backspace:
            self.save_state()
            if self.selected_items:
                for item in self.selected_items:
                    if type(item).__name__ == "Wire":
                        self.connection_manager.remove_wire(item.a, item.b)
                    elif type(item).__name__ == "VirtualComponent":
                        self.connection_manager.remove_component(item.node)
                self.selected_items.clear()
            elif self.hover_node:
                self.connection_manager.remove_node_wires(self.hover_node)
            elif self.hover_wire:
                self.connection_manager.remove_wire(self.hover_wire.a, self.hover_wire.b)
            self.update()
            return
            
        super().keyPressEvent(event)

    def mouseDoubleClickEvent(self, event):
        self.start_node = None 
        self.update()
        if event.button() == Qt.MouseButton.LeftButton:
            clicked_node, _ = self._get_hits(event.position(), ignore_wires=True)
            if clicked_node:
                comp = self.connection_manager.get_component_at(clicked_node)
                if comp:
                    self.componentDoubleClicked.emit(comp.id)

    def _tick(self):
        self.pulse += 0.15
        if self.glitch_timer > 0:
            self.glitch_timer -= 1
        self.update()
        
    def trigger_glitch(self):
        self.glitch_timer = 10

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        if getattr(self, 'glitch_timer', 0) > 0:
            import random
            intensity = self.glitch_timer / 10.0
            dx = random.uniform(-1, 1) * 3.5 * intensity
            dy = random.uniform(-1, 1) * 2.0 * intensity
            painter.translate(dx, dy)

        active_net = None
        if self.start_node:
            active_net = self.connection_manager.component(self.start_node)
            active_net.add(self.start_node)
        elif self.selected_network:
            active_net = self.selected_network

        # 1. Background (Advanced PCB Matrix)
        painter.fillRect(self.rect(), QColor("#0C0C0F"))

        painter.setPen(QPen(QColor("#16161B"), 1))
        # Draw techy background traces occasionally connecting nodes statically
        for r in range(self.ROWS):
            for c in range(self.COLS):
                if (r * 7 + c * 3) % 5 == 0:
                    p1 = self._node_pos(NodeRef(r, c))
                    if c < self.COLS - 1:
                        p2 = self._node_pos(NodeRef(r, c + 1))
                        painter.drawLine(p1, p2)
                    if r < self.ROWS - 1:
                        p3 = self._node_pos(NodeRef(r + 1, c))
                        painter.drawLine(p1, p3)

        # 2. Breadboard Base Body
        g = self._geom()
        board = g["rect"]
        body = board.adjusted(-34, -34, 34, 34)
        
        # 3D Gradient Base
        base_grad = QLinearGradient(body.topLeft(), body.bottomRight())
        base_grad.setColorAt(0.0, QColor("#2A2A30"))
        base_grad.setColorAt(1.0, QColor("#1D1D22"))
        painter.setBrush(base_grad)
        
        # Outer border / drop shadow effect
        painter.setPen(QPen(QColor("#111115"), 2))
        painter.drawRoundedRect(body, 12, 12)
        
        # Inner highlight bevel
        inner_highlight = body.adjusted(2, 2, -2, -2)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.setPen(QPen(QColor("#3A3A45"), 1))
        painter.drawRoundedRect(inner_highlight, 10, 10)

        # 3D Trench
        trench = QRectF(board.left() + 10, g["trench_top"], board.width() - 20, g["trench_bottom"] - g["trench_top"])
        trench_grad = QLinearGradient(trench.topLeft(), trench.bottomLeft())
        trench_grad.setColorAt(0.0, QColor("#121215"))  # Deep dark shadow at top
        trench_grad.setColorAt(1.0, QColor("#1A1A1E"))  # Slightly lighter base
        painter.setBrush(trench_grad)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawRoundedRect(trench, 6, 6)
        
        # Trench inner shadow highlight
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.setPen(QPen(QColor("#000000"), 1.5))
        painter.drawLine(trench.topLeft() + QPointF(6, 0), trench.topRight() - QPointF(6, 0))

        text_alpha = 60 if active_net else 255

        # 3. RAILS AND TEXT 
        xL, xR = g["x_left"] - 20, g["x_right"] + 20
        # Omit row 11's rail line
        for y, col in ((g["stripe_top_plus"], QColor("#FF3B30")), 
                       (g["stripe_bot_plus"], QColor("#666666")), 
                       (g["stripe_bot_minus"], QColor("#32CD32"))):
            rail_col = QColor(col)
            rail_col.setAlpha(int(text_alpha * 0.65)) 
            painter.setPen(QPen(rail_col, 1.5, Qt.PenStyle.DashLine, Qt.PenCapStyle.FlatCap))
            painter.drawLine(QPointF(xL, y), QPointF(xR, y))

        txt_pen_col = QColor("#8E8E93")
        txt_pen_col.setAlpha(text_alpha)
        painter.setPen(QPen(txt_pen_col, 1))
        painter.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
        
        red_txt_col = QColor("#FF3B30")
        red_txt_col.setAlpha(text_alpha)
        painter.setPen(QPen(red_txt_col, 2))
        painter.drawText(QPointF(xL - 35, g["stripe_top_plus"] + 5), "+8V")
        
        gnd_txt_col = QColor("#32CD32")
        gnd_txt_col.setAlpha(text_alpha)
        painter.setPen(QPen(gnd_txt_col, 2))
        painter.drawText(QPointF(xL - 38, g["stripe_bot_minus"] + 5), "GND")
        
        neg_txt_col = QColor("#AAAAAA")
        neg_txt_col.setAlpha(text_alpha)
        painter.setPen(QPen(neg_txt_col, 2))
        painter.drawText(QPointF(xL - 35, g["stripe_bot_plus"] + 5), "-8V")

        lbl_col = QColor("#A0A0A5")
        lbl_col.setAlpha(text_alpha)
        painter.setPen(QPen(lbl_col, 1))
        for col in range(self.COLS):
            top_text = str(col + 3)
            bot_text = str(col + 33)
            x = g["term_x"][col]
            top_offset = 4 if len(top_text) == 1 else 9
            bot_offset = 4 if len(bot_text) == 1 else 9
            painter.drawText(QPointF(x - top_offset, g["top_row_y"][0] - 14), top_text)
            painter.drawText(QPointF(x - bot_offset, g["bot_row_y"][-1] + 24), bot_text)

        for r, letter in enumerate(["A", "B", "C", "D", "E"]):
            painter.drawText(QPointF(xL - 22, g["top_row_y"][r] + 4), letter)
        for r, letter in enumerate(["F", "G", "H", "I", "J"]):
            painter.drawText(QPointF(xL - 22, g["bot_row_y"][r] + 4), letter)

        # 4. HOLES
        for r in range(self.ROWS):
            for c in range(self.COLS):
                n = NodeRef(r, c)
                p = self._node_pos(n)

                is_active = not active_net or n in active_net
                is_interacted = (self.start_node == n) or (self.hover_node == n)

                housing_color = QColor("#3D3D48") if (is_active or is_interacted) else QColor("#2A2A30")

                # Draw square indent for hole housing rather than plain ellipse
                indent_rect = QRectF(p.x() - 4.5, p.y() - 4.5, 9.0, 9.0)
                
                painter.setPen(Qt.PenStyle.NoPen)
                painter.setBrush(QColor("#141418"))  # Dark deep hole
                painter.drawRoundedRect(indent_rect, 2.0, 2.0)
                
                # Bottom & Right highlight (bevel)
                painter.setPen(QPen(housing_color, 1.0))
                painter.drawLine(indent_rect.bottomLeft() + QPointF(2, 0), indent_rect.bottomRight() - QPointF(2, 0))
                painter.drawLine(indent_rect.topRight() + QPointF(0, 2), indent_rect.bottomRight() - QPointF(0, 2))
                
                # Top & Left shadow (bevel)
                painter.setPen(QPen(QColor("#08080B"), 1.0))
                painter.drawLine(indent_rect.topLeft() + QPointF(2, 0), indent_rect.topRight() - QPointF(2, 0))
                painter.drawLine(indent_rect.topLeft() + QPointF(0, 2), indent_rect.bottomLeft() - QPointF(0, 2))

                # Tiny inner metallic contact clip
                clip_rect = QRectF(p.x() - 1.5, p.y() - 1.5, 3.0, 3.0)
                painter.setBrush(QColor("#2C2C35")) # Dark metallic
                painter.setPen(Qt.PenStyle.NoPen)
                painter.drawRoundedRect(clip_rect, 0.5, 0.5)

        # 5. WIRES RENDER
        painter.setBrush(Qt.BrushStyle.NoBrush) 
        
        # Pass 1: Faded/Inactive Wires
        if active_net:
            for w in self.connection_manager.wires:
                is_hovered = (w is self.hover_wire)
                if w.a not in active_net and w.b not in active_net and not is_hovered:
                    path = self._build_wire_path(w)
                    painter.setBrush(Qt.BrushStyle.NoBrush)
                    fade_col = QColor(w.color)
                    fade_col.setAlpha(45)
                    painter.setPen(QPen(fade_col, 3.5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
                    painter.drawPath(path)
                    
                    for node in (w.a, w.b):
                        p = self._node_pos(node)
                        grip_rect = QRectF(p.x() - 3.5, p.y() - 3.5, 7.0, 7.0)
                        painter.setBrush(QColor(fade_col.red(), fade_col.green(), fade_col.blue(), 40))
                        painter.setPen(Qt.PenStyle.NoPen)
                        painter.drawRoundedRect(grip_rect, 1.5, 1.5)

        # Pass 2: Active/Highlighted Wires
        painter.setBrush(Qt.BrushStyle.NoBrush)
        for w in self.connection_manager.wires:
            is_hovered = (w is self.hover_wire)
            is_selected = (w is self.selected_wire)

            if not active_net or w.a in active_net or w.b in active_net or is_hovered:
                path = self._build_wire_path(w)
                
                if active_net and (w.a in active_net or w.b in active_net):
                    glow = QColor(w.color)
                    glow.setAlpha(80)
                    painter.setPen(QPen(glow, 7.0, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
                    painter.drawPath(path)

                if is_hovered or is_selected:
                    highlight_col = QColor("#FFFFFF")
                    highlight_col.setAlpha(160 if (is_hovered and not is_selected) else 255)
                    painter.setPen(QPen(highlight_col, 8.5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
                    painter.drawPath(path)

                shadow_col = QColor("#000000")
                shadow_col.setAlpha(120)
                painter.setPen(QPen(shadow_col, 5.0, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
                painter.drawPath(path)
                
                base_color = QColor(w.color)
                painter.setPen(QPen(base_color, 3.5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
                painter.drawPath(path)
                
                # Cylindrical Specular Highlight
                specular = base_color.lighter(150)
                painter.setPen(QPen(specular, 1.2, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
                painter.drawPath(path)


        # Pass 4: Live Preview Wire Render
        painter.setBrush(Qt.BrushStyle.NoBrush)
        if self.start_node and self.hover_node and self.start_node != self.hover_node and self.tool == "wire":
            preview_color = self.connection_manager.node_color(self.start_node)
            if not preview_color:
                preview_color = self.wire_color
                 
            wire_hash = (self.start_node.row + self.hover_node.row + self.start_node.col + self.hover_node.col) % 5
            offset = (wire_hash - 2) * 6.0
                
            preview_wire = Wire(self.start_node, self.hover_node, preview_color, float(offset))
            path = self._build_wire_path(preview_wire)
             
            preview_pen = QPen(preview_color, 3.5, Qt.PenStyle.DashLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
            painter.setPen(preview_pen)
            painter.drawPath(path)

        # 6. NODE COLOR BLOCKS & HOVER GLOW
        routing_color = self.wire_color
        if self.start_node:
            sc = self.connection_manager.node_color(self.start_node)
            if sc: routing_color = sc
                
        for r in range(self.ROWS):
            for c in range(self.COLS):
                n = NodeRef(r, c)
                p = self._node_pos(n)
                node_color = self.connection_manager.node_color(n)
                
                is_active = not active_net or n in active_net
                is_interacted = (self.start_node == n) or (self.hover_node == n)

                if node_color or is_interacted:
                    if node_color:
                        fill_color = QColor(node_color)
                    elif self.start_node and is_interacted:
                        fill_color = QColor(routing_color)
                    else:
                        fill_color = QColor(self.wire_color)

                    if not is_active and not is_interacted:
                        fill_color.setAlpha(35)
                    
                    painter.setBrush(fill_color)
                    painter.setPen(Qt.PenStyle.NoPen)
                    painter.drawEllipse(p, 2.5, 2.5)

                    is_target_pulse = self.start_node is not None and self.hover_node == n
                    if self.start_node == n or is_target_pulse:
                        pulse_r = 9.0 + 2.0 * math.sin(self.pulse)
                        painter.setBrush(QColor(fill_color.red(), fill_color.green(), fill_color.blue(), 120))
                        painter.setPen(Qt.PenStyle.NoPen)
                        painter.drawEllipse(p, pulse_r, pulse_r)
                    
                    elif self.hover_node == n and self.start_node is None:
                        painter.setPen(QPen(fill_color, 1.5))
                        painter.setBrush(Qt.BrushStyle.NoBrush)
                        painter.drawEllipse(p, 6.0, 6.0)

        # 7. VIRTUAL COMPONENTS RENDER (HIGH-FIDELITY CHIPS)
        for comp in self.connection_manager.components:
            p = self._node_pos(comp.node)
            painter.save()
            painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
            
            if comp.type == 'probe':
                color = QColor("#32CD32")
                label = f"D{comp.channel + 1}"
            elif comp.type == 'signal':
                color = QColor("#58a6ff")
                label = f"S{comp.channel}"
            elif comp.type == 'power':
                color = QColor("#ef476f")
                label = f"P{comp.channel}"
                
            chip_rect = QRectF(p.x() - 15, p.y() - 20, 30, 40)
            is_selected = comp in getattr(self, 'selected_items', [])
            
            # Outer Glowing Highlight BEFORE drawing the box body
            if is_selected:
                outer_glow = QColor(color)
                outer_glow.setAlpha(90)
                painter.setPen(QPen(outer_glow, 7.0, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.MiterJoin))
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawRoundedRect(chip_rect, 4.0, 4.0)
            
            # Metallic Gradient Body
            bg_grad = QLinearGradient(chip_rect.topLeft(), chip_rect.bottomLeft())
            bg_grad.setColorAt(0.0, QColor("#35353A"))
            bg_grad.setColorAt(1.0, QColor("#18181D"))
            painter.setBrush(bg_grad)
            
            # Colored Border representing selection
            border_width = 2.0 if is_selected else 1.0
            painter.setPen(QPen(color, border_width))
            painter.drawRoundedRect(chip_rect, 4.0, 4.0)
            
            # Text Label Division
            text_area_height = 13
            text_bg = QRectF(chip_rect.x(), chip_rect.bottom() - text_area_height, chip_rect.width(), text_area_height)
            
            # Text Divider Line
            painter.setPen(QPen(QColor("#404045"), 1.0))
            painter.drawLine(QPointF(chip_rect.left(), text_bg.top()), QPointF(chip_rect.right(), text_bg.top()))
            
            # Sharp High-Contrast Text
            painter.setPen(QColor("#FFFFFF"))
            painter.setFont(QFont("Consolas", 8, QFont.Weight.Bold))
            painter.drawText(text_bg, Qt.AlignmentFlag.AlignCenter, label)
            
            # Centered Graphic Icons (Shifted up so they safely fit above the text area)
            cy_icon = p.y() - 7
            draw_custom_icon(painter, p.x(), cy_icon, comp.type, color)
            
            painter.restore()

        # 8. DRAG SELECT BOX & HIGHLIGHTS
        if getattr(self, 'drag_select_start', None) and getattr(self, 'drag_select_current', None):
            r = QRectF(self.drag_select_start, self.drag_select_current).normalized()
            painter.setPen(QPen(QColor("#58a6ff"), 2.0, Qt.PenStyle.DashLine))
            glow = QColor("#58a6ff")
            glow.setAlpha(60)
            painter.setBrush(glow)
            painter.drawRect(r)
            
        for item in getattr(self, 'selected_items', []):
            if isinstance(item, Wire):
                path = self._build_wire_path(item)
                glow = QColor(item.color)
                glow.setAlpha(210)
                painter.setPen(QPen(glow, 7.0, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawPath(path)
                
                outer_glow = QColor(item.color)
                outer_glow.setAlpha(80)
                painter.setPen(QPen(outer_glow, 14.0, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
                painter.drawPath(path)
                
                painter.setPen(QPen(QColor(item.color), 3.5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
                painter.drawPath(path)

        # Pass 9: Realistic Jumper End Grips (Draw over all highlights)
        for w in self.connection_manager.wires:
            is_hovered = (w is self.hover_wire)
            is_selected = (w in getattr(self, 'selected_items', [])) or (w is getattr(self, 'selected_wire', None))
            
            if not active_net or w.a in active_net or w.b in active_net or is_hovered or is_selected:
                base_color = QColor(w.color)
                for node in (w.a, w.b):
                    p = self._node_pos(node)
                    
                    # Main Body
                    grip_rect = QRectF(p.x() - 3.5, p.y() - 3.5, 7.0, 7.0)
                    painter.setBrush(base_color.darker(110))
                    painter.setPen(QPen(QColor("#111111"), 1.0))
                    painter.drawRoundedRect(grip_rect, 1.5, 1.5)
                    
                    # Specular Top Reflection for Grip
                    painter.setBrush(base_color.lighter(130))
                    painter.setPen(Qt.PenStyle.NoPen)
                    painter.drawRoundedRect(QRectF(p.x() - 2.5, p.y() - 2.5, 5.0, 3.0), 1.0, 1.0)
                    
                    # Tiny metallic pin in center
                    painter.setBrush(QColor("#D0D0D5"))
                    painter.drawEllipse(QRectF(p.x() - 1.0, p.y() - 1.0, 2.0, 2.0))

        if getattr(self, 'glitch_timer', 0) > 0:
            painter.resetTransform()
            intensity = self.glitch_timer / 15.0
            overlay = QColor(230, 57, 70, int(40 * intensity))
            painter.fillRect(self.rect(), overlay)
            
            # High tech digital scanline glitch effect
            painter.setPen(QColor(230, 57, 70, int(80 * intensity)))
            import random
            for _ in range(5):
                y = random.randint(0, self.height())
                painter.drawLine(0, y, self.width(), y)

class ToolButton(QPushButton):
    def __init__(self, icon_type, text, parent=None):
        super().__init__(parent)
        self.icon_type = icon_type
        self.full_text = text
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumHeight(48)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        bg_col = QColor("#31313A") if self.underMouse() else QColor("#25252B")
        if self.isDown(): 
            bg_col = QColor("#E63946")
        
        painter.setBrush(bg_col)
        is_active = self.property("active") == True
        pen = QPen(QColor("#E63946"), 2) if is_active else QPen(QColor("#3A3A45"), 1)
        painter.setPen(pen)
        painter.drawRoundedRect(self.rect().adjusted(1,1,-2,-2), 6, 6)
        
        cx = 24
        cy = 24
        base_color = QColor("#58a6ff") if self.icon_type == "signal" else QColor("#E63946")
        if self.icon_type == "probe": base_color = QColor("#32CD32")
        draw_custom_icon(painter, cx, cy, self.icon_type, base_color)

        if self.width() > 100:
            painter.setPen(QColor("#FFFFFF"))
            font = self.font()
            font.setPointSize(11)
            font.setBold(True)
            painter.setFont(font)
            text_rect = QRectF(48, 0, self.width() - 52, self.height())
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, self.full_text)

class ToolPanel(QFrame):
    def __init__(self, board: BreadboardWidget):
        super().__init__()
        self.board = board
        self.setObjectName("ToolPanel")
        self.setMinimumWidth(64)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 16, 8, 16)
        layout.setSpacing(12)

        self.btn_select = ToolButton("select", "Select Tool")
        self.btn_wire = ToolButton("wire", "Wire Tool")
        self.btn_eraser = ToolButton("eraser", "Delete")
        self.btn_signal = ToolButton("signal", "Inject Signal")
        self.btn_power = ToolButton("power", "Supply Power")
        self.btn_probe = ToolButton("probe", "Add Probe")

        self.buttons = {
            "select": self.btn_select,
            "wire": self.btn_wire,
            "eraser": self.btn_eraser,
            "place_signal": self.btn_signal,
            "place_power": self.btn_power,
            "place_probe": self.btn_probe
        }

        for k, btn in self.buttons.items():
            layout.addWidget(btn)
            btn.clicked.connect(lambda checked=False, tool=k: self.set_active_tool(tool))
            
        layout.addStretch(1)
        self.set_active_tool("wire")
        
        self._sync_timer = QTimer(self)
        self._sync_timer.timeout.connect(self._sync_tool)
        self._sync_timer.start(100)
        
    def set_active_tool(self, tool):
        self.board.set_tool(tool)
        self._sync_tool()
        
    def _sync_tool(self):
        for k, btn in self.buttons.items():
            is_act = (self.board.tool == k)
            if btn.property("active") != is_act:
                btn.setProperty("active", is_act)
                btn.update()