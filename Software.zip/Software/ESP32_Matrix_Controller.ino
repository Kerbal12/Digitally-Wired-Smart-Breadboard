#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define OLED_SDA 22
#define OLED_SCL 23
Adafruit_SSD1306 display(128, 64, &Wire1, -1);

// -------- OLED Core 0 State & Locks --------
int oled_state = 0; // 0=boot, 1=idle, 2=connecting, 3=clearing
int oled_node_a = -1;
int oled_node_b = -1;
unsigned long oled_last_action = 0;
portMUX_TYPE oledMux = portMUX_INITIALIZER_UNLOCKED;

// -------- ESP32 Pins --------
#define I2C_SDA  14 
#define I2C_SCL  13
#define MCP_RST  12
#define CH_CLK   18 
#define CH_DAT   19  
#define CH_RST   21 

// -------- MCP23017 Addresses & Registers --------
#define U9_ADDR  0x20
#define U11_ADDR 0x21
#define IODIRA   0x00
#define IODIRB   0x01
#define GPIOA    0x12
#define GPIOB    0x13

uint8_t u9_porta = 0x00;  
uint8_t u9_portb = 0x00;  
uint8_t u11_portb = 0x00; 

// Updated struct includes offset logic for gap handling
struct ChipDef {
  uint8_t id;
  uint8_t x_min; uint8_t x_max;
  uint8_t y_min; uint8_t y_max;
  uint8_t x_int_offset; // Shifter for internal X pins (X8-X15)
  uint8_t y_int_offset; // Shifter for internal Y pins
};

// Array size increased to 28 to handle the "split" chips perfectly
const int MATRIX_SIZE = 28;
ChipDef matrix[MATRIX_SIZE] = {
  // Standard Chips (No offset needed)
  {1, 1, 16, 1, 8, 0, 0},    {2, 17, 32, 1, 8, 0, 0},   {3, 33, 48, 1, 8, 0, 0},   {4, 49, 64, 1, 8, 0, 0},
  {5, 9, 24, 9, 16, 0, 0},   {6, 25, 40, 9, 16, 0, 0},  {7, 41, 56, 9, 16, 0, 0},
  
  // L8 Split: Main X and Instrument X
  {8, 57, 64, 9, 16, 0, 0},  {8, 65, 72, 9, 16, 8, 0},
  
  {9, 17, 32, 17, 24, 0, 0}, {10, 33, 48, 17, 24, 0, 0},{11, 49, 64, 17, 24, 0, 0},
  {12, 25, 40, 25, 32, 0, 0},{13, 41, 56, 25, 32, 0, 0},
  
  // L14 Split
  {14, 57, 64, 25, 32, 0, 0},{14, 65, 72, 25, 32, 8, 0},
  
  {15, 33, 48, 33, 40, 0, 0},{16, 49, 64, 33, 40, 0, 0},
  {17, 41, 56, 41, 48, 0, 0},
  
  // L18 Split
  {18, 57, 64, 41, 48, 0, 0},{18, 65, 72, 41, 48, 8, 0},
  
  {19, 49, 64, 49, 56, 0, 0},
  
  // L20 Split
  {20, 57, 64, 57, 64, 0, 0},{20, 65, 72, 57, 64, 8, 0},

  // L21 Split: Main X ranges + Y Instruments
  {21, 33, 40, 65, 72, 0, 0},{21, 49, 56, 65, 72, 8, 0},

  // L23 Split: Main X ranges + Y Instruments
  {23, 1, 8, 65, 72, 0, 0},  {23, 17, 24, 65, 72, 8, 0}
};

void MCP_Write(uint8_t addr, uint8_t reg, uint8_t data) {
  Wire.beginTransmission(addr);
  Wire.write(reg);
  Wire.write(data);
  Wire.endTransmission();
}

void ClearSwitchesSilent() {
  digitalWrite(CH_RST, HIGH); 
  delay(5);
  digitalWrite(CH_RST, LOW); 
  delay(5);
}

void Matrix_HardReset() {
  digitalWrite(MCP_RST, LOW); delay(10);
  digitalWrite(MCP_RST, HIGH); delay(20);
  MCP_Write(U9_ADDR, IODIRA, 0x00); MCP_Write(U9_ADDR, GPIOA, 0x00);
  MCP_Write(U9_ADDR, IODIRB, 0x00); MCP_Write(U9_ADDR, GPIOB, 0x00);
  MCP_Write(U11_ADDR, IODIRB, 0x00); MCP_Write(U11_ADDR, GPIOB, 0x00);
  u9_porta = 0; u9_portb = 0; u11_portb = 0;
  ClearSwitchesSilent();
  
  portENTER_CRITICAL(&oledMux);
  oled_state = 3;
  oled_last_action = millis();
  portEXIT_CRITICAL(&oledMux);
  
  Serial.println("\n--- Matrix Reset: All connections OPEN ---");
}

void Pulse_STB(uint8_t chip_id) {
  if (chip_id >= 1 && chip_id <= 8) {
    u9_portb |= (1 << (chip_id - 1));
    MCP_Write(U9_ADDR, GPIOB, u9_portb); delay(10);
    u9_portb &= ~(1 << (chip_id - 1));
    MCP_Write(U9_ADDR, GPIOB, u9_portb);
  } else if (chip_id >= 9 && chip_id <= 16) {
    u9_porta |= (1 << (chip_id - 9));
    MCP_Write(U9_ADDR, GPIOA, u9_porta); delay(10);
    u9_porta &= ~(1 << (chip_id - 9));
    MCP_Write(U9_ADDR, GPIOA, u9_porta);
  } else if (chip_id >= 17 && chip_id <= 20) {
    u11_portb |= (1 << (chip_id - 17));
    MCP_Write(U11_ADDR, GPIOB, u11_portb); delay(10);
    u11_portb &= ~(1 << (chip_id - 17));
    MCP_Write(U11_ADDR, GPIOB, u11_portb);
  } else if (chip_id == 21) {
    u11_portb |= (1 << 5); // Corrected to GPB5
    MCP_Write(U11_ADDR, GPIOB, u11_portb); delay(10);
    u11_portb &= ~(1 << 5);
    MCP_Write(U11_ADDR, GPIOB, u11_portb);
  } else if (chip_id == 23) {
    u11_portb |= (1 << 4); // Corrected to GPB4
    MCP_Write(U11_ADDR, GPIOB, u11_portb); delay(10);
    u11_portb &= ~(1 << 4);
    MCP_Write(U11_ADDR, GPIOB, u11_portb);
  }
}
void CH446Q_WriteSwitch(uint8_t chip_id, uint8_t int_x, uint8_t int_y, bool connect) {
  uint8_t addr = (int_y * 16) + int_x;
  digitalWrite(CH_DAT, LOW); delay(2);
  for (int i = 7; i >= 0; i--) {
    digitalWrite(CH_CLK, LOW);
    digitalWrite(CH_DAT, (addr >> i) & 1);
    digitalWrite(CH_CLK, HIGH);
  }
  digitalWrite(CH_CLK, LOW);
  digitalWrite(CH_DAT, connect ? HIGH : LOW); delay(2);
  Pulse_STB(chip_id);
}

// Returns false if no chip can handle the connection
bool RouteConnection(int nodeA, int nodeB, bool silent = false) {
  if (nodeA == nodeB) return false;

  for (int i = 0; i < MATRIX_SIZE; i++) {
    bool A_on_X = (nodeA >= matrix[i].x_min && nodeA <= matrix[i].x_max);
    bool B_on_Y = (nodeB >= matrix[i].y_min && nodeB <= matrix[i].y_max);
    bool B_on_X = (nodeB >= matrix[i].x_min && nodeB <= matrix[i].x_max);
    bool A_on_Y = (nodeA >= matrix[i].y_min && nodeA <= matrix[i].y_max);

    if ((A_on_X && B_on_Y) || (B_on_X && A_on_Y)) {
      uint8_t int_x, int_y;
      if (A_on_X && B_on_Y) {
        int_x = (nodeA - matrix[i].x_min) + matrix[i].x_int_offset;
        int_y = (nodeB - matrix[i].y_min) + matrix[i].y_int_offset;
      } else {
        int_x = (nodeB - matrix[i].x_min) + matrix[i].x_int_offset;
        int_y = (nodeA - matrix[i].y_min) + matrix[i].y_int_offset;
      }
      CH446Q_WriteSwitch(matrix[i].id, int_x, int_y, true);
      
      portENTER_CRITICAL(&oledMux);
      oled_state = 2;
      oled_node_a = nodeA;
      oled_node_b = nodeB;
      oled_last_action = millis();
      portEXIT_CRITICAL(&oledMux);
      
      if (!silent) {
        Serial.printf("Connected %d to %d (Chip L%d, int X%d Y%d)\n", nodeA, nodeB, matrix[i].id, int_x, int_y);
      }
      return true;
    }
  }
  if (!silent) Serial.printf("Error: No path for %d to %d\n", nodeA, nodeB);
  return false;
}

#define DSO_PIN_CH1 26
#define DSO_PIN_CH2 27
unsigned long lastSampleTime = 0;
const unsigned long sampleInterval = 1000; // 1 ms for 1000 Hz

struct InstrumentChannel {
  float freq;
  float vpp;
  float duty;
  int wave;
  float dc;
  int source;
};
InstrumentChannel sys_channels[4];
int activeCmdChannel = 0;

void WriteDACVoltageSilent(int src, float voltage) {
  if (voltage < -7.0) voltage = -7.0;
  if (voltage > 7.0) voltage = 7.0;
  
  if (src == 0) { // Only Channel A
    // MCP4728 Calibrated Output
    int dac_val = constrain(round((voltage + 8.017) * 209.68), 0, 4095);
    
    Wire.beginTransmission(0x60);
    Wire.write(0x40 | (src << 1)); // 0x40 = 01000000 -> Multi-Write to DAC Register (No EEPROM)
    Wire.write((dac_val >> 8) & 0x0F);
    Wire.write(dac_val & 0xFF);
    Wire.endTransmission();
  }
}

float phase[4] = {0,0,0,0};
unsigned long lastGenTime = 0;

void oledTask(void * pvParameters) {
  for(;;) {
    int state;
    int na, nb;
    unsigned long act_time;
    
    portENTER_CRITICAL(&oledMux);
    state = oled_state;
    na = oled_node_a;
    nb = oled_node_b;
    act_time = oled_last_action;
    portEXIT_CRITICAL(&oledMux);
    
    display.clearDisplay();
    unsigned long now = millis();
    
    if (state == 0) {
      int step = (now - act_time) / 250; 
      if (step > 8) {
        portENTER_CRITICAL(&oledMux);
        if (oled_state == 0) oled_state = 1;
        portEXIT_CRITICAL(&oledMux);
      } else {
        display.setTextSize(1);
        display.setTextColor(WHITE);
        display.setCursor(0, 0); 
        display.print("> INIT I2C_CORE");
        if(step > 0) { display.setCursor(100, 0); display.print("[OK]"); }
        if(step > 1) { display.setCursor(0, 10); display.print("> RTOS KERNEL"); }
        if(step > 2) { display.setCursor(100, 10); display.print("[OK]"); }
        if(step > 3) { display.setCursor(0, 20); display.print("> MATRIX MOUNT"); }
        if(step > 4) { display.setCursor(100, 20); display.print("[OK]"); }
        if(step > 5) { display.setCursor(0, 30); display.print("> CALIBRATION"); }
        if(step > 6) { display.setCursor(100, 30); display.print("[OK]"); }
        if(step > 7) { 
          display.fillRect(0, 45, 128, 19, WHITE);
          display.setTextColor(BLACK);
          display.setTextSize(2);
          display.setCursor(20, 48);
          display.print("ON-LINE");
        }
      }
    } 
    else if (state == 3) {
      int sweep = (now - act_time) * 128 / 600; 
      if (sweep > 135) {
        portENTER_CRITICAL(&oledMux);
        if (oled_state == 3) oled_state = 1;
        portEXIT_CRITICAL(&oledMux);
      } else {
        display.setTextSize(2);
        display.setTextColor(WHITE);
        display.setCursor(4, 24);
        display.print("DATA PURGE");
        for(int i = 0; i < 64; i += 6) {
           display.drawFastHLine(0, i, sweep, WHITE);
           display.drawFastHLine(128 - sweep, i + 2, sweep, WHITE);
        }
      }
    }
    else if (state == 2) {
      if (now - act_time > 1500) {
        portENTER_CRITICAL(&oledMux);
        if (oled_state == 2) oled_state = 1;
        portEXIT_CRITICAL(&oledMux);
      } else {
        display.setTextSize(1);
        display.setTextColor(WHITE);
        display.setCursor(0, 0);
        display.print(">> ALLOCATING TIE <<");
        display.drawLine(0, 9, 128, 9, WHITE);
        
        display.drawRect(8, 20, 36, 24, WHITE);
        display.drawRect(84, 20, 36, 24, WHITE);
        display.drawLine(8, 20, 12, 20, BLACK);
        display.drawLine(84, 20, 88, 20, BLACK);
        
        display.setTextSize(2);
        display.setCursor(12, 25); display.print(na);
        display.setCursor(88, 25); display.print(nb);
        
        int x_offset = (now / 15) % 36;
        display.drawFastHLine(46, 32, 36, WHITE);
        display.fillRect(46 + x_offset, 30, 4, 5, INVERSE);
        
        display.setTextSize(1);
        if ((now / 200) % 2 == 0) {
            display.setCursor(40, 52); display.print("[LOCKED]");
        } else {
            display.setCursor(40, 52); display.print(" LOCKED ");
        }
      }
    }
    else if (state == 1) {
      display.setTextSize(1);
      display.setTextColor(WHITE);
      display.setCursor(20, 3);
      display.print("DIGITALLY WIRED");
      display.setCursor(16, 15);
      display.print("SMART BREADBOARD");
      
      display.drawLine(4, 26, 124, 26, WHITE);
      
      int bb_x = 24;
      int bb_y = 31;
      int bb_w = 80;
      int bb_h = 32;
      display.drawRoundRect(bb_x, bb_y, bb_w, bb_h, 3, WHITE);
      
      display.drawLine(bb_x, bb_y + 15, bb_x + bb_w, bb_y + 15, WHITE);
      display.drawLine(bb_x, bb_y + 16, bb_x + bb_w, bb_y + 16, WHITE);
      
      for (int c = 4; c <= bb_w - 4; c += 8) {
        for (int r = 3; r <= 11; r += 3) {
          display.drawPixel(bb_x + c, bb_y + r, WHITE);       
          display.drawPixel(bb_x + c, bb_y + 17 + r, WHITE);  
        }
      }
      
      int anim = (now / 20) % 200; 
      int rx1 = bb_x + 12;
      int ry1 = bb_y + 6;
      int rx2 = bb_x + 60;
      int ry2 = bb_y + 26;
      
      if (anim > 20 && anim < 180) {
         float t = min(1.0f, (anim - 20) / 30.0f);
         int cx = rx1 + (rx2 - rx1) * t;
         int cy = ry1 + (ry2 - ry1) * t;
         
         display.drawLine(rx1, ry1, cx, cy, WHITE);
         
         display.drawPixel(rx1, ry1, BLACK); 
         display.drawPixel(cx, cy, BLACK);
         display.drawRect(rx1-1, ry1-1, 3, 3, WHITE);
         if(t >= 1.0f) display.drawRect(rx2-1, ry2-1, 3, 3, WHITE);
         
         if (t >= 1.0f) {
           int pulse = (now / 15) % 100;
           if (pulse < 80) {
             float pt = pulse / 80.0f;
             int px = rx1 + (rx2 - rx1) * pt;
             int py = ry1 + (ry2 - ry1) * pt;
             display.fillRect(px-1, py-1, 3, 3, INVERSE);
           }
         }
      }
    }
    
    display.display();
    vTaskDelay(pdMS_TO_TICKS(33));
  }
}

void setup() {
  Serial.begin(921600); 
  Serial.setTimeout(5); 
  Wire.begin(I2C_SDA, I2C_SCL);
  Wire1.begin(OLED_SDA, OLED_SCL);
  
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) { 
    Serial.println("SSD1306 allocation failed");
  } else {
    display.clearDisplay();
    display.display();
  }

  oled_last_action = millis();
  oled_state = 0;
  xTaskCreatePinnedToCore(
    oledTask,
    "OLED_Task",
    4096,
    NULL,
    1,
    NULL,
    0 // PIN TO CORE 0
  );

  pinMode(MCP_RST, OUTPUT); pinMode(CH_CLK, OUTPUT);
  pinMode(CH_DAT, OUTPUT); pinMode(CH_RST, OUTPUT);
  pinMode(DSO_PIN_CH1, INPUT);
  pinMode(DSO_PIN_CH2, INPUT);

  // Initialize channels
  for (int i=0; i<4; i++) {
    sys_channels[i].freq = 30.0;
    sys_channels[i].vpp = 0.0; // Default to DC output off smoothly
    sys_channels[i].duty = 50.0;
    sys_channels[i].wave = 0;
    sys_channels[i].dc = 0.0;
    sys_channels[i].source = 0; // Default lock to MCP Channel A
  }

  analogReadResolution(12); // Ensure ADC is 12-bit
  
  // Power down MCP4728 Channels B (1) and C (2) completely
  for (int ch = 1; ch <= 2; ch++) {
    Wire.beginTransmission(0x60);
    Wire.write(0x40 | (ch << 1));
    Wire.write(0x60); // PD1=1, PD0=1 -> 500k power down
    Wire.write(0x00);
    Wire.endTransmission();
  }
  
  Matrix_HardReset();
  lastSampleTime = micros();
  Serial.println("\n--- READY ---");
  Serial.println("Commands:");
  Serial.println(" - Type '5,65' to connect Pin 5 to FNPS1.");
  Serial.println(" - Type 'clear' to reset all switches.");
}

void loop() {
  unsigned long currentMicros = micros();
  
  // Function Generator Continuous Output
  float dt = (currentMicros - lastGenTime) / 1000000.0;
  lastGenTime = currentMicros;
  
  for (int i = 0; i < 4; i++) {
    if (sys_channels[i].vpp > 0.001) {
      phase[i] += sys_channels[i].freq * dt;
      while (phase[i] >= 1.0) phase[i] -= 1.0;
      
      float val = 0.0;
      bool is_pulse = false;
      if (sys_channels[i].wave == 0) { // Sine
        val = sin(phase[i] * 2.0 * PI);
      } else if (sys_channels[i].wave == 1) { // Square
        val = (phase[i] < 0.5) ? 1.0 : -1.0;
      } else if (sys_channels[i].wave == 2) { // Triangle
        if (phase[i] < 0.25) val = phase[i] * 4.0;
        else if (phase[i] < 0.75) val = 1.0 - (phase[i] - 0.25) * 4.0;
        else val = -1.0 + (phase[i] - 0.75) * 4.0;
      } else if (sys_channels[i].wave == 3) { // Pulse
        val = (phase[i] < (sys_channels[i].duty / 100.0)) ? 1.0 : 0.0;
        is_pulse = true;
      }
      
      float out_v = sys_channels[i].dc + val * (is_pulse ? sys_channels[i].vpp : (sys_channels[i].vpp / 2.0));
      WriteDACVoltageSilent(sys_channels[i].source, out_v);
    }
  }

  // Probe Signal Polling
  if (currentMicros - lastSampleTime >= sampleInterval) {
    lastSampleTime += sampleInterval;
    long adc1 = 0, adc2 = 0;
    for(int i=0; i<8; i++) {
      adc1 += analogRead(DSO_PIN_CH1); 
      adc2 += analogRead(DSO_PIN_CH2);
    }
    adc1 >>= 3; adc2 >>= 3;
    
    Serial.printf("%ld,%ld\n", adc1, adc2);
  }

  if (Serial.available() > 0) {
    String input = Serial.readStringUntil('\n');
    input.trim();
    
    if (input.length() == 0) return;

    if (input.equalsIgnoreCase("clear")) {
      Matrix_HardReset();
      // Shut off all analog function generator outputs so they don't capacitively couple
      // to floating ADC pins when components are deleted/cleared in the GUI.
      for(int c=0; c<4; c++) {
        sys_channels[c].vpp = 0.0;
        sys_channels[c].dc = 0.0;
        WriteDACVoltageSilent(sys_channels[c].source, 0.0);
      }
    } 
    else {
      int commaIndex = input.indexOf(',');
      if (commaIndex > 0) {
        int nA = input.substring(0, commaIndex).toInt();
        int nB = input.substring(commaIndex + 1).toInt();
        RouteConnection(nA, nB);
      } 
      else if (input.length() == 4 && isDigit(input.charAt(0)) && isDigit(input.charAt(1))) {
        int nA = input.substring(0, 2).toInt();
        int nB = input.substring(2, 4).toInt();
        RouteConnection(nA, nB);
      }
      else {
        // Parse GUI string instrument commands
        char cmd = input.charAt(0);
        String valStr = input.substring(1);
        if (cmd == 'p') {
          activeCmdChannel = valStr.toInt();
          if (activeCmdChannel > 3) activeCmdChannel = 3;
        } else if (cmd == 'F') {
          sys_channels[activeCmdChannel].freq = valStr.toFloat();
        } else if (cmd == 'V') {
          sys_channels[activeCmdChannel].vpp = valStr.toFloat();
          if (sys_channels[activeCmdChannel].vpp < 0.001) WriteDACVoltageSilent(sys_channels[activeCmdChannel].source, sys_channels[activeCmdChannel].dc);
        } else if (cmd == 'D') {
          sys_channels[activeCmdChannel].duty = valStr.toFloat();
        } else if (cmd == 'W') {
          sys_channels[activeCmdChannel].wave = valStr.toInt();
        } else if (cmd == 'P') {
          sys_channels[activeCmdChannel].dc = valStr.toFloat();
          if (sys_channels[activeCmdChannel].vpp < 0.001) WriteDACVoltageSilent(sys_channels[activeCmdChannel].source, sys_channels[activeCmdChannel].dc);
        } else if (cmd == 'S') {
          sys_channels[activeCmdChannel].source = valStr.toInt();
          if (sys_channels[activeCmdChannel].vpp < 0.001) WriteDACVoltageSilent(sys_channels[activeCmdChannel].source, sys_channels[activeCmdChannel].dc);
        }
      }
    }
  }
}
