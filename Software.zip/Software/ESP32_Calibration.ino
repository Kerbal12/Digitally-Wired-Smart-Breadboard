#include <Arduino.h>
#include <Wire.h>

// -------- ESP32 Pins --------
#define I2C_SDA  14 
#define I2C_SCL  13
#define MCP_RST  12
#define CH_CLK   18 
#define CH_DAT   19  
#define CH_RST   21 

// -------- MCP23017 Addresses & Registers --------
#define U9_ADDR  0x20
#define U11_ADDR 0x21
#define IODIRA   0x00
#define IODIRB   0x01
#define GPIOA    0x12
#define GPIOB    0x13

uint8_t u9_porta = 0x00;  
uint8_t u9_portb = 0x00;  
uint8_t u11_portb = 0x00; 

struct ChipDef {
  uint8_t id;
  uint8_t x_min; uint8_t x_max;
  uint8_t y_min; uint8_t y_max;
  uint8_t x_int_offset;
  uint8_t y_int_offset;
};

// ORIGINAL MATRIX TOPOLOGY - 100% UNTOUCHED
const int MATRIX_SIZE = 28;
ChipDef matrix[MATRIX_SIZE] = {
  {1, 1, 16, 1, 8, 0, 0},    {2, 17, 32, 1, 8, 0, 0},   {3, 33, 48, 1, 8, 0, 0},   {4, 49, 64, 1, 8, 0, 0},
  {5, 9, 24, 9, 16, 0, 0},   {6, 25, 40, 9, 16, 0, 0},  {7, 41, 56, 9, 16, 0, 0},
  {8, 57, 64, 9, 16, 0, 0},  {8, 65, 72, 9, 16, 8, 0},
  {9, 17, 32, 17, 24, 0, 0}, {10, 33, 48, 17, 24, 0, 0},{11, 49, 64, 17, 24, 0, 0},
  {12, 25, 40, 25, 32, 0, 0},{13, 41, 56, 25, 32, 0, 0},
  {14, 57, 64, 25, 32, 0, 0},{14, 65, 72, 25, 32, 8, 0},
  {15, 33, 48, 33, 40, 0, 0},{16, 49, 64, 33, 40, 0, 0},
  {17, 41, 56, 41, 48, 0, 0},
  {18, 57, 64, 41, 48, 0, 0},{18, 65, 72, 41, 48, 8, 0},
  {19, 49, 64, 49, 56, 0, 0},
  {20, 57, 64, 57, 64, 0, 0},{20, 65, 72, 57, 64, 8, 0},
  {21, 33, 40, 65, 72, 0, 0},{21, 49, 56, 65, 72, 8, 0},
  {23, 1, 8, 65, 72, 0, 0},  {23, 17, 24, 65, 72, 8, 0}
};

void MCP_Write(uint8_t addr, uint8_t reg, uint8_t data) {
  Wire.beginTransmission(addr);
  Wire.write(reg);
  Wire.write(data);
  Wire.endTransmission();
}

void ClearSwitchesSilent() {
  digitalWrite(CH_RST, HIGH); 
  delay(5);
  digitalWrite(CH_RST, LOW); 
  delay(5);
}

void Matrix_HardReset() {
  digitalWrite(MCP_RST, LOW); delay(10);
  digitalWrite(MCP_RST, HIGH); delay(20);
  MCP_Write(U9_ADDR, IODIRA, 0x00); MCP_Write(U9_ADDR, GPIOA, 0x00);
  MCP_Write(U9_ADDR, IODIRB, 0x00); MCP_Write(U9_ADDR, GPIOB, 0x00);
  MCP_Write(U11_ADDR, IODIRB, 0x00); MCP_Write(U11_ADDR, GPIOB, 0x00);
  u9_porta = 0; u9_portb = 0; u11_portb = 0;
  ClearSwitchesSilent();
}

// Original Pulse_STB function
void Pulse_STB(uint8_t chip_id) {
  if (chip_id >= 1 && chip_id <= 8) {
    u9_portb |= (1 << (chip_id - 1));
    MCP_Write(U9_ADDR, GPIOB, u9_portb); delay(2);
    u9_portb &= ~(1 << (chip_id - 1));
    MCP_Write(U9_ADDR, GPIOB, u9_portb);
  } else if (chip_id >= 9 && chip_id <= 16) {
    u9_porta |= (1 << (chip_id - 9));
    MCP_Write(U9_ADDR, GPIOA, u9_porta); delay(2);
    u9_porta &= ~(1 << (chip_id - 9));
    MCP_Write(U9_ADDR, GPIOA, u9_porta);
  } else if (chip_id >= 17 && chip_id <= 20) {
    u11_portb |= (1 << (chip_id - 17));
    MCP_Write(U11_ADDR, GPIOB, u11_portb); delay(2);
    u11_portb &= ~(1 << (chip_id - 17));
    MCP_Write(U11_ADDR, GPIOB, u11_portb);
  } else if (chip_id == 21) {
    u11_portb |= (1 << 5);
    MCP_Write(U11_ADDR, GPIOB, u11_portb); delay(2);
    u11_portb &= ~(1 << 5);
    MCP_Write(U11_ADDR, GPIOB, u11_portb);
  } else if (chip_id == 23) {
    u11_portb |= (1 << 4);
    MCP_Write(U11_ADDR, GPIOB, u11_portb); delay(2);
    u11_portb &= ~(1 << 4);
    MCP_Write(U11_ADDR, GPIOB, u11_portb);
  }
}

void CH446Q_WriteSwitch(uint8_t chip_id, uint8_t int_x, uint8_t int_y, bool connect) {
  uint8_t addr = (int_y * 16) + int_x;
  digitalWrite(CH_DAT, LOW); delayMicroseconds(50);
  for (int i = 7; i >= 0; i--) {
    digitalWrite(CH_CLK, LOW);
    digitalWrite(CH_DAT, (addr >> i) & 1);
    digitalWrite(CH_CLK, HIGH);
  }
  digitalWrite(CH_CLK, LOW);
  digitalWrite(CH_DAT, connect ? HIGH : LOW); delayMicroseconds(50);
  Pulse_STB(chip_id);
}

// Original RouteConnection Function
bool RouteConnection(int nodeA, int nodeB) {
  if (nodeA == nodeB) return false;
  for (int i = 0; i < MATRIX_SIZE; i++) {
    bool A_on_X = (nodeA >= matrix[i].x_min && nodeA <= matrix[i].x_max);
    bool B_on_Y = (nodeB >= matrix[i].y_min && nodeB <= matrix[i].y_max);
    bool B_on_X = (nodeB >= matrix[i].x_min && nodeB <= matrix[i].x_max);
    bool A_on_Y = (nodeA >= matrix[i].y_min && nodeA <= matrix[i].y_max);

    if ((A_on_X && B_on_Y) || (B_on_X && A_on_Y)) {
      uint8_t int_x, int_y;
      if (A_on_X && B_on_Y) {
        int_x = (nodeA - matrix[i].x_min) + matrix[i].x_int_offset;
        int_y = (nodeB - matrix[i].y_min) + matrix[i].y_int_offset;
      } else {
        int_x = (nodeB - matrix[i].x_min) + matrix[i].x_int_offset;
        int_y = (nodeA - matrix[i].y_min) + matrix[i].y_int_offset;
      }
      CH446Q_WriteSwitch(matrix[i].id, int_x, int_y, true);
      return true;
    }
  }
  return false;
}

// Using your exact established power supply math
void WriteDACVoltageSilent(int src, float voltage) {
  if (voltage < -7.0) voltage = -7.0;
  if (voltage > 7.0) voltage = 7.0;
  
  if (src == 0) { 
    int dac_val = constrain(round((voltage + 8.017) * 209.68), 0, 4095);
    Wire.beginTransmission(0x60);
    Wire.write(0x40 | (src << 1)); 
    Wire.write((dac_val >> 8) & 0x0F);
    Wire.write(dac_val & 0xFF);
    Wire.endTransmission();
  }
}

// Validating the pins!
#define DSO_PIN_CH1 26
#define DSO_PIN_CH2 27

void setup() {
  Serial.begin(921600);
  Wire.begin(I2C_SDA, I2C_SCL);
  pinMode(MCP_RST, OUTPUT); pinMode(CH_CLK, OUTPUT);
  pinMode(CH_DAT, OUTPUT); pinMode(CH_RST, OUTPUT);
  pinMode(DSO_PIN_CH1, INPUT);
  pinMode(DSO_PIN_CH2, INPUT);

  analogReadResolution(12);

  // Initializing the MCP
  for (int ch = 1; ch <= 2; ch++) {
    Wire.beginTransmission(0x60);
    Wire.write(0x40 | (ch << 1));
    Wire.write(0x60); 
    Wire.write(0x00);
    Wire.endTransmission();
  }

  Matrix_HardReset();
  
  delay(5000); // Wait for Serial Monitor
  
  // ====== THE BULLETPROOF ROUTING FIX ======
  // Route Power (65) and Scopes (69, 71) through intermediate Breadboard Node (10)
  // This automatically routes through L8 internally without hitting blind spots!
  RouteConnection(65, 10); delay(50);
  RouteConnection(69, 10); delay(50);
  RouteConnection(71, 10); delay(100);

  Serial.println("[");

  // Perform the sweep (-7V to +7V with 0.1V step for dense data points)
  for (float v = -7.0; v <= 7.01; v += 0.1) {
    WriteDACVoltageSilent(0, v);
    delay(20); 
    
    long adc1 = 0, adc2 = 0;
    const int samples = 2048; // Massively increased for clean averaging
    
    // Quick burst of raw samples to defeat high frequency noise
    for(int i = 0; i < samples; i++) {
        adc1 += analogRead(DSO_PIN_CH1); 
        adc2 += analogRead(DSO_PIN_CH2);
    }
    
    adc1 /= samples; 
    adc2 /= samples;
    
    bool isLast = (v >= 6.99);
    Serial.printf("  {\"v\":%.2f, \"adc1\":%ld, \"adc2\":%ld}%s\n", v, adc1, adc2, isLast ? "" : ",");
  }
  
  Serial.println("]");
  
  WriteDACVoltageSilent(0, 0.0);
}

void loop() {
}
